
package Modelo;

import Clases.Cliente;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;




public class Cliente_Modelo {
    Connection cn;
    PreparedStatement ps;
    ResultSet rs;
    Conexion con=new Conexion();
    
    public boolean Reguistrar_cliente(Cliente cl){
        Cliente cliente=null;
    String sql="INSERT INTO clientes (id, nombre, apellidos, edad, telefono,ciudad, direccion,email, fecha de reguistro,targeta ,numero de cuenra";
        try {
            cn=con.getConeConnection();
             ps = cn.prepareStatement(sql);
           ps.setInt(1, cl.getId());
            ps.setString(1, cl.getNombres());
            ps.setString(2, cl.getApellidos());
            ps.setInt(1, cl.getEdad());
            ps.setInt(1, cl.getTeléfono());
            ps.setString(2, cl.getCiudad());
            ps.setString(1, cl.getDirección());
            ps.setString(2, cl.getEmail());
          //  ps.setDate(2, cl.getFecha_registro());
            ps.setInt(1, cl.getNúmero_cuenta());
            ps.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
            return false;
        }finally {
            try {
                cn.close();
            } catch (SQLException e) {
                System.out.println(e.toString());
            }
       }
    }
    
}
