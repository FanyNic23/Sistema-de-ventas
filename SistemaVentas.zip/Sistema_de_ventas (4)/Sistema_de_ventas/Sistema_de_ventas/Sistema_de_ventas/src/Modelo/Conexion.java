package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;


public abstract class Conexion<T> {
    private Connection cn;
    
    public Conexion(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/productora_celis_srl", "root", "");
            //System.out.println("Conexion abierta");
        } catch (Exception e) {
            System.out.println("Error: "+e.getMessage());
        }
    }

    public Connection getCn() {
        return cn;
    }
    public abstract int insertar(T objeto);
    public abstract ArrayList<T> lista();
    public abstract int actualizar(T obj);
    public abstract int eliminar(T obj);
    
}