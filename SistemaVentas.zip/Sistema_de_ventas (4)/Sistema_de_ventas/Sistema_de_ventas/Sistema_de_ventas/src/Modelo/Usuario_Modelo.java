package Modelo;

import Clases.Usuario;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Usuario_Modelo extends Conexion<Usuario>{
    private Connection con;
    private PreparedStatement sp;
    private ResultSet result;

    public Usuario_Modelo() {
        super();
        this.con = getCn();
    }

    @Override
    public int insertar(Usuario objeto) {
        try {
            String sql="INSERT INTO `usuario`(`nombres`, `apellidos`,`edad`, `dni` , `genero`, `email`, `contrasenia`, `cargo`) VALUES (?,?,?,?,?,?,?,?)";
            sp= con.prepareStatement(sql);
            
            sp.setString(1, objeto.getNombres());
            sp.setString(2, objeto.getApellidos());
            sp.setString(3, objeto.getDni());
            sp.setString(5, objeto.getGénero()+"");
            sp.setString(6, objeto.getCargo());
            sp.setString(7, objeto.getEmail());
            sp.setString(8, objeto.getContrasenia());
            
            int res = sp.executeUpdate();
            
            sp.close();
            con.close();
            
            return res;
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public ArrayList<Usuario> lista() {
        ArrayList<Usuario> lista= new ArrayList<>();
        
        String sql="SELECT `id`, `nombres`, `apellidos`,`edad`, `dni` , `genero`, `email`, `contrasenia`, `cargo` FROM `usuario`";
        
        try {
            Statement st= con.createStatement();
            
            result=st.executeQuery(sql);
            
            while (result.next()) {   
                Usuario u = new Usuario();
                
                u.setId(result.getInt(1));
                u.setNombres(result.getString(2));
                u.setApellidos(result.getString(3));
                u.setEdad(result.getInt(4));
                u.setDni(result.getString(5));
                u.setEmail(result.getString(6));
                u.setContrasenia(result.getString(7));
                u.setCargo(result.getString(8));
                
                lista.add(u);
            }
        } catch (SQLException ex) {
            System.out.println("Error: "+ex.getMessage());
        } 
        
        return lista;
    }

    @Override
    public int actualizar(Usuario obj) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int eliminar(Usuario obj) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     
}
