package Clases;

import java.util.Date;

public class Cliente extends Usuario{
    private int teléfono;
    private String ciudad;
    private String dirección;   
    private Date fecha_registro;
    private String tarjeta;
    private int número_cuenta;

    public Cliente() {
    }
    

    public Cliente(int teléfono, String ciudad, String dirección, Date fecha_registro, String tarjeta, int número_cuenta, int id, String nombres, String apellidos, int edad, String dni, char género, String email, String contrasenia, String cargo) {
        super(id, nombres, apellidos, edad, dni, género, email, contrasenia, cargo);
        this.teléfono = teléfono;
        this.ciudad = ciudad;
        this.dirección = dirección;
        this.fecha_registro = fecha_registro;
        this.tarjeta = tarjeta;
        this.número_cuenta = número_cuenta;
    }

    public int getTeléfono() {
        return teléfono;
    }

    public void setTeléfono(int teléfono) {
        this.teléfono = teléfono;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getDirección() {
        return dirección;
    }

    public void setDirección(String dirección) {
        this.dirección = dirección;
    }

    public Date getFecha_registro() {
        return fecha_registro;
    }

    public void setFecha_registro(Date fecha_registro) {
        this.fecha_registro = fecha_registro;
    }

    public String getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(String tarjeta) {
        this.tarjeta = tarjeta;
    }

    public int getNúmero_cuenta() {
        return número_cuenta;
    }

    public void setNúmero_cuenta(int número_cuenta) {
        this.número_cuenta = número_cuenta;
    }
    


}
