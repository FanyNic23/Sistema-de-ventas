
package Clases;

import java.util.Date;


public class Productos_Lacteos {
    private int codigo;
    private String NOMBRE;
    private String DESCRIPCION;
    private int CANTIDAD;
    private Date FECHA_VENCIMIENTO;
    private double PRECIO_UNITARIO;
    private double DESCUENTO;
    private int stock;
    private String Proveedor;

    public Productos_Lacteos(int codigo, String NOMBRE, String DESCRIPCION, int CANTIDAD, Date FECHA_VENCIMIENTO, double PRECIO_UNITARIO, double DESCUENTO, int stock, String Proveedor) {
        this.codigo = codigo;
        this.NOMBRE = NOMBRE;
        this.DESCRIPCION = DESCRIPCION;
        this.CANTIDAD = CANTIDAD;
        this.FECHA_VENCIMIENTO = FECHA_VENCIMIENTO;
        this.PRECIO_UNITARIO = PRECIO_UNITARIO;
        this.DESCUENTO = DESCUENTO;
        this.stock = stock;
        this.Proveedor = Proveedor;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public String getDESCRIPCION() {
        return DESCRIPCION;
    }

    public int getCANTIDAD() {
        return CANTIDAD;
    }

    public Date getFECHA_VENCIMIENTO() {
        return FECHA_VENCIMIENTO;
    }

    public double getPRECIO_UNITARIO() {
        return PRECIO_UNITARIO;
    }

    public double getDESCUENTO() {
        return DESCUENTO;
    }

    public int getStock() {
        return stock;
    }

    public String getProveedor() {
        return Proveedor;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setNOMBRE(String NOMBRE) {
        this.NOMBRE = NOMBRE;
    }

    public void setDESCRIPCION(String DESCRIPCION) {
        this.DESCRIPCION = DESCRIPCION;
    }

    public void setCANTIDAD(int CANTIDAD) {
        this.CANTIDAD = CANTIDAD;
    }

    public void setFECHA_VENCIMIENTO(Date FECHA_VENCIMIENTO) {
        this.FECHA_VENCIMIENTO = FECHA_VENCIMIENTO;
    }

    public void setPRECIO_UNITARIO(double PRECIO_UNITARIO) {
        this.PRECIO_UNITARIO = PRECIO_UNITARIO;
    }

    public void setDESCUENTO(double DESCUENTO) {
        this.DESCUENTO = DESCUENTO;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setProveedor(String Proveedor) {
        this.Proveedor = Proveedor;
    }

   

    

}
    

