
package Clases;


import java.util.Date;


public class Carrito_Compras extends Productos_Lacteos{
    private int Orden_Compra;

    public Carrito_Compras(int codigo, String NOMBRE, String DESCRIPCION, int CANTIDAD, Date FECHA_VENCIMIENTO, double PRECIO_UNITARIO, double DESCUENTO, int stock, String Proveedor) {
        super(codigo, NOMBRE, DESCRIPCION, CANTIDAD, FECHA_VENCIMIENTO, PRECIO_UNITARIO, DESCUENTO, stock, Proveedor);
    }

    public Carrito_Compras(int Orden_Compra, int codigo, String NOMBRE, String DESCRIPCION, int CANTIDAD, Date FECHA_VENCIMIENTO, double PRECIO_UNITARIO, double DESCUENTO, int stock, String Proveedor) {
        super(codigo, NOMBRE, DESCRIPCION, CANTIDAD, FECHA_VENCIMIENTO, PRECIO_UNITARIO, DESCUENTO, stock, Proveedor);
        this.Orden_Compra = Orden_Compra;
    }

    public int getOrden_Compra() {
        return Orden_Compra;
    }

    public void setOrden_Compra(int Orden_Compra) {
        this.Orden_Compra = Orden_Compra;
    }

   

    

    
    
    
}
