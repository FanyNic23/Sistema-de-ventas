package Clases;

import java.time.LocalDate;

public class Delivery extends Usuario{
   
    private LocalDate fecha_pedido;
    private LocalDate fecha_entrega;
    private int telefono;
    private String direccion_Entrega;
    private int tiempo_Entrega;
    private double costo;


    public Delivery(LocalDate fecha_pedido, LocalDate fecha_entrega, int telefono, String direccion_Entrega, int tiempo_Entrega, double costo, int id, String nombres, String apellidos, int edad, String dni, char género, String email, String contrasenia, String cargo) {
        super(id, nombres, apellidos, edad, dni, género, email, contrasenia, cargo);
        this.fecha_pedido = fecha_pedido;
        this.fecha_entrega = fecha_entrega;
        this.telefono = telefono;
        this.direccion_Entrega = direccion_Entrega;
        this.tiempo_Entrega = tiempo_Entrega;
        this.costo = costo;
    }

    public LocalDate getFecha_pedido() {
        return fecha_pedido;
    }

    public void setFecha_pedido(LocalDate fecha_pedido) {
        this.fecha_pedido = fecha_pedido;
    }

    public LocalDate getFecha_entrega() {
        return fecha_entrega;
    }

    public void setFecha_entrega(LocalDate fecha_entrega) {
        this.fecha_entrega = fecha_entrega;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getDireccion_Entrega() {
        return direccion_Entrega;
    }

    public void setDireccion_Entrega(String direccion_Entrega) {
        this.direccion_Entrega = direccion_Entrega;
    }

    public int getTiempo_Entrega() {
        return tiempo_Entrega;
    }

    public void setTiempo_Entrega(int tiempo_Entrega) {
        this.tiempo_Entrega = tiempo_Entrega;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

  
}
