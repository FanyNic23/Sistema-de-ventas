
package Clases;


import java.util.Date;

/**
 *
 * @author fany_
 */
public class Pedido extends Productos_Lacteos   {
    private int código;
    private Date fecha;
    private Delivery delivery;
    private String Tarjeta;
    private int NumCuenta;
    private double precio_total;

    public Pedido(int codigo, String NOMBRE, String DESCRIPCION, int CANTIDAD, Date FECHA_VENCIMIENTO, double PRECIO_UNITARIO, double DESCUENTO, int stock, String Proveedor) {
        super(codigo, NOMBRE, DESCRIPCION, CANTIDAD, FECHA_VENCIMIENTO, PRECIO_UNITARIO, DESCUENTO, stock, Proveedor);
    }

    public Pedido(int código, Date fecha, Delivery delivery, String Tarjeta, int NumCuenta, double precio_total, int codigo, String NOMBRE, String DESCRIPCION, int CANTIDAD, Date FECHA_VENCIMIENTO, double PRECIO_UNITARIO, double DESCUENTO, int stock, String Proveedor) {
        super(codigo, NOMBRE, DESCRIPCION, CANTIDAD, FECHA_VENCIMIENTO, PRECIO_UNITARIO, DESCUENTO, stock, Proveedor);
        this.código = código;
        this.fecha = fecha;
        this.delivery = delivery;
        this.Tarjeta = Tarjeta;
        this.NumCuenta = NumCuenta;
        this.precio_total = precio_total;
    }

    public int getCódigo() {
        return código;
    }

    public Date getFecha() {
        return fecha;
    }

    public Delivery getDelivery() {
        return delivery;
    }

    public String getTarjeta() {
        return Tarjeta;
    }

    public int getNumCuenta() {
        return NumCuenta;
    }

    public double getPrecio_total() {
        return precio_total;
    }

    public void setCódigo(int código) {
        this.código = código;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setDelivery(Delivery delivery) {
        this.delivery = delivery;
    }

    public void setTarjeta(String Tarjeta) {
        this.Tarjeta = Tarjeta;
    }

    public void setNumCuenta(int NumCuenta) {
        this.NumCuenta = NumCuenta;
    }

    public void setPrecio_total(double precio_total) {
        this.precio_total = precio_total;
    }
   

   
   
   
}
