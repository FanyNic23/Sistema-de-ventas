package Clases;

public class Usuario {
    private int id;
    private String nombres;
    private String apellidos;
    private int edad;
    private String dni;
    private char género;
    private String email;
    private String contrasenia;
    private String cargo;
   
    public Usuario() {
    }
    
    public Usuario(int id, String nombres, String apellidos, int edad, String dni, char género, String email, String contrasenia, String cargo) {
        this.id = id;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.edad = edad;
        this.dni = dni;
        this.género = género;
        this.email = email;
        this.contrasenia = contrasenia;
        this.cargo = cargo;
    }

    public Usuario(String nombres, String apellidos, int edad, String dni, char género, String email, String contrasenia, String cargo) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.edad = edad;
        this.dni = dni;
        this.género = género;
        this.email = email;
        this.contrasenia = contrasenia;
        this.cargo = cargo;
    }

    public Usuario(String email, String contrasenia) {
        this.email = email;
        this.contrasenia = contrasenia;
    }
    
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public char getGénero() {
        return género;
    }

    public void setGénero(char género) {
        this.género = género;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
   public String[] getData() {
    return new String[]{ "" + id, nombres, apellidos, String.valueOf(edad), dni, género + "", email, contrasenia, cargo};
     }
    

 
}
