
package Clases;

import java.util.Date;


public class Comprobante_Pago extends Pedido{
    private String Ruc_Empresa;
    private int Telefono_empresa;
    private String Direccion_Empresa;
    private String cliente;
    private String vendedor;

    public Comprobante_Pago(String Ruc_Empresa, int Telefono_empresa, String Direccion_Empresa, String cliente, String vendedor, int codigo, String NOMBRE, String DESCRIPCION, int CANTIDAD, Date FECHA_VENCIMIENTO, double PRECIO_UNITARIO, double DESCUENTO, int stock, String Proveedor) {
        super(codigo, NOMBRE, DESCRIPCION, CANTIDAD, FECHA_VENCIMIENTO, PRECIO_UNITARIO, DESCUENTO, stock, Proveedor);
        this.Ruc_Empresa = Ruc_Empresa;
        this.Telefono_empresa = Telefono_empresa;
        this.Direccion_Empresa = Direccion_Empresa;
        this.cliente = cliente;
        this.vendedor = vendedor;
    }

    public Comprobante_Pago(String Ruc_Empresa, int Telefono_empresa, String Direccion_Empresa, String cliente, String vendedor, int código, Date fecha, Delivery delivery, String Tarjeta, int NumCuenta, double precio_total, int codigo, String NOMBRE, String DESCRIPCION, int CANTIDAD, Date FECHA_VENCIMIENTO, double PRECIO_UNITARIO, double DESCUENTO, int stock, String Proveedor) {
        super(código, fecha, delivery, Tarjeta, NumCuenta, precio_total, codigo, NOMBRE, DESCRIPCION, CANTIDAD, FECHA_VENCIMIENTO, PRECIO_UNITARIO, DESCUENTO, stock, Proveedor);
        this.Ruc_Empresa = Ruc_Empresa;
        this.Telefono_empresa = Telefono_empresa;
        this.Direccion_Empresa = Direccion_Empresa;
        this.cliente = cliente;
        this.vendedor = vendedor;
    }

    public String getRuc_Empresa() {
        return Ruc_Empresa;
    }

    public int getTelefono_empresa() {
        return Telefono_empresa;
    }

    public String getDireccion_Empresa() {
        return Direccion_Empresa;
    }

    public String getCliente() {
        return cliente;
    }

    public String getVendedor() {
        return vendedor;
    }

    public void setRuc_Empresa(String Ruc_Empresa) {
        this.Ruc_Empresa = Ruc_Empresa;
    }

    public void setTelefono_empresa(int Telefono_empresa) {
        this.Telefono_empresa = Telefono_empresa;
    }

    public void setDireccion_Empresa(String Direccion_Empresa) {
        this.Direccion_Empresa = Direccion_Empresa;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public void setVendedor(String vendedor) {
        this.vendedor = vendedor;
    }

  

  
  
   
    
}
