package Clases;

public class Proveedor extends Usuario{
    private int teléfono;
    private String dirección;
    private String ruc;
    private String razón_social;
    private String ciudad;



    public Proveedor(int teléfono, String dirección, String ruc, String razón_social, String ciudad, int id, String nombres, String apellidos, int edad, String dni, char género, String email, String contrasenia, String cargo) {
        super(id, nombres, apellidos, edad, dni, género, email, contrasenia, cargo);
        this.teléfono = teléfono;
        this.dirección = dirección;
        this.ruc = ruc;
        this.razón_social = razón_social;
        this.ciudad = ciudad;
    }

    public int getTeléfono() {
        return teléfono;
    }

    public void setTeléfono(int teléfono) {
        this.teléfono = teléfono;
    }

    public String getDirección() {
        return dirección;
    }

    public void setDirección(String dirección) {
        this.dirección = dirección;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getRazón_social() {
        return razón_social;
    }

    public void setRazón_social(String razón_social) {
        this.razón_social = razón_social;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }




}
