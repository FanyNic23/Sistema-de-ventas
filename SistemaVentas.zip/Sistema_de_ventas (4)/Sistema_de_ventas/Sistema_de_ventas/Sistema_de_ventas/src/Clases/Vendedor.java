package Clases;

public class Vendedor extends Usuario{
    private int teléfono;
    private String dirección;
    private String ciudad;


    public Vendedor(int teléfono, String dirección, String ciudad, int id, String nombres, String apellidos, int edad, String dni, char género, String email, String contrasenia, String cargo) {
        super(id, nombres, apellidos, edad, dni, género, email, contrasenia, cargo);
        this.teléfono = teléfono;
        this.dirección = dirección;
        this.ciudad = ciudad;
    }

    public int getTeléfono() {
        return teléfono;
    }

    public void setTeléfono(int teléfono) {
        this.teléfono = teléfono;
    }

    public String getDirección() {
        return dirección;
    }

    public void setDirección(String dirección) {
        this.dirección = dirección;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }


    
}
