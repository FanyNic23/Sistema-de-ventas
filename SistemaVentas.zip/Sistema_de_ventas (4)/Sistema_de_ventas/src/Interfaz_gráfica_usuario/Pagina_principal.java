package Interfaz_gráfica_usuario;

import Clases_Personas.Administracion;
import Clases_Personas.Clientes;
import Clases_Personas.Proveedores;
import Clases_Personas.Vendedores;
import Clases_Productos.Carrito_de_compras;
import Clases_Productos.Comprobante;
import Clases_Productos.Delivery;
import Clases_Productos.Pedidos;
import Clases_Productos.Producto;
import Modelo.Conexion;
import java.sql.DriverManager;
import Modelo.Modelo_Administracion;
import Modelo.Modelo_Clientes;
import Modelo.Modelo_Delivery;
import Modelo.Modelo_Pedidos;
import Modelo.Modelo_Producto;
import Modelo.Modelo_Proveedores;
import Modelo.Modelo_Vendedores;
import Modelo.Modelo_Carrito;
import Modelo.Modelo_Comprobante;
import java.sql.Connection;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class Pagina_principal extends javax.swing.JFrame {

    Modelo_Administracion modelAdm = new Modelo_Administracion();
    Modelo_Producto modelPro = new Modelo_Producto();
    Modelo_Pedidos modelPed = new Modelo_Pedidos();
    Modelo_Proveedores modelProv = new Modelo_Proveedores();
    Modelo_Clientes modelCli = new Modelo_Clientes();
    Modelo_Vendedores modelVen = new Modelo_Vendedores();
    Modelo_Delivery modelDel = new Modelo_Delivery();
    Modelo_Carrito modelCar = new Modelo_Carrito();
    Modelo_Comprobante modelCompro = new Modelo_Comprobante();
    private Connection cn;

    public void cerrarConexion() {
        try {
            if (cn != null && !cn.isClosed()) {
                cn.close();
            }
        } catch (Exception e) {
            System.out.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }

    public Pagina_principal() {
        initComponents();
        mostrarAdmins();
        mostrarProductos();
        mostrarPedidos();
        mostrarClientes();
        Mostrar_Vendedores();
        mostrarProveedores();
        MostrarDelivery();
        mostrarProductos_Carrito();
        MostrarCarrito();
        Mostrar_Cmprobante();

    }

    @SuppressWarnings("unchecked")

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Verificacion_Usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Verificacion_Usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Verificacion_Usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Verificacion_Usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pagina_principal().setVisible(true);
            }
        });
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField6 = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jButton_EMPRESA = new javax.swing.JButton();
        jButton_ADMINISTRADOR = new javax.swing.JButton();
        jButton_CLIENTES = new javax.swing.JButton();
        jButton_VENDEDOR = new javax.swing.JButton();
        jButton_PROVEEDOR = new javax.swing.JButton();
        jButton_PRODUCTOS_LACTEOS = new javax.swing.JButton();
        jButton_PEDIDOS = new javax.swing.JButton();
        jButton_CARRITO_COMPRAS = new javax.swing.JButton();
        jButton_DELIVERY = new javax.swing.JButton();
        jButton_COMPROBANTE_PAGO = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        Jbutton_CerrarConexion = new javax.swing.JButton();
        Productos = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Jtable_admins = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        TxT_ideliminar = new javax.swing.JTextField();
        Button_EliminarAdm = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        JtableCli = new javax.swing.JTable();
        Clientes = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jButton1_AGREGAR_CLIENTES = new javax.swing.JButton();
        txt_IDC = new javax.swing.JTextField();
        txt_NOMBREC = new javax.swing.JTextField();
        txt_APELLIDOC = new javax.swing.JTextField();
        txt_DNIC = new javax.swing.JTextField();
        txt_EDADC = new javax.swing.JTextField();
        Button_EliminaClientes = new javax.swing.JButton();
        txt_NUMERO_TELEFONICOC = new javax.swing.JTextField();
        txt_CLIENTE_CARGOC = new javax.swing.JTextField();
        txt_CONTRASEÑAC = new javax.swing.JTextField();
        jLabel95 = new javax.swing.JLabel();
        rbutton_ClienteMasculino = new javax.swing.JRadioButton();
        rbutton_ClienteFemenino = new javax.swing.JRadioButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        JtableVendedores = new javax.swing.JTable();
        Empleados = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        jbutton_ContratarEmp = new javax.swing.JButton();
        txt_IDven = new javax.swing.JTextField();
        txt_NOMBREven = new javax.swing.JTextField();
        txt_APELLIDOven = new javax.swing.JTextField();
        txt_DNIven = new javax.swing.JTextField();
        txt_EDADven = new javax.swing.JTextField();
        jbutton_despedirEmp = new javax.swing.JButton();
        txt_NUMEROTEven = new javax.swing.JTextField();
        txt_CARGOven = new javax.swing.JTextField();
        txt_PAGOMENSUALven = new javax.swing.JTextField();
        jLabel105 = new javax.swing.JLabel();
        rbutton_VendedorMasculino1 = new javax.swing.JRadioButton();
        rbutton_VendedorFemenino = new javax.swing.JRadioButton();
        jLabel106 = new javax.swing.JLabel();
        txt_CONTRASEÑAven = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jScrollPane13 = new javax.swing.JScrollPane();
        jTableProveedor = new javax.swing.JTable();
        Clientes1 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jbutton_Agregarproveedor = new javax.swing.JButton();
        txt_idproveedor = new javax.swing.JTextField();
        txt_nombreproveedor = new javax.swing.JTextField();
        txt_apellidoproveedor = new javax.swing.JTextField();
        txt_dniproveedor = new javax.swing.JTextField();
        txt_edadproveedor = new javax.swing.JTextField();
        jbutton_eliminarproveedor = new javax.swing.JButton();
        txt_numerotelproveedor = new javax.swing.JTextField();
        txt_cargoproveedor = new javax.swing.JTextField();
        txt_contraseñaproveedor = new javax.swing.JTextField();
        jLabel116 = new javax.swing.JLabel();
        rbutton_ProveedorMasculino = new javax.swing.JRadioButton();
        rbutton_ProveedorFemenina = new javax.swing.JRadioButton();
        jLabel117 = new javax.swing.JLabel();
        txt_razonsocialproveedor = new javax.swing.JTextField();
        jLabel118 = new javax.swing.JLabel();
        txt_calidadproveedor = new javax.swing.JTextField();
        jLabel119 = new javax.swing.JLabel();
        txt_lugardeorigenproveedor = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        Jtable_productos = new javax.swing.JTable();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        Button_RegistrarProducto = new javax.swing.JButton();
        txt_idelproducto = new javax.swing.JTextField();
        txt_nombredelproducto = new javax.swing.JTextField();
        txt_descripcion = new javax.swing.JTextField();
        txt_stock = new javax.swing.JTextField();
        txt_fechadevencimiento = new javax.swing.JTextField();
        Button_EliminarProducto = new javax.swing.JButton();
        txt_preciounitarioproduc = new javax.swing.JTextField();
        txt_descuento = new javax.swing.JTextField();
        txt_idproveedorProd = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        Jtable_pedidos = new javax.swing.JTable();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        TxT_codigopedido = new javax.swing.JTextField();
        TxT_descripcionpedido = new javax.swing.JTextField();
        TxT_idvendedorpedido = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        txt_fechaped = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        TxT_Direciconpedido = new javax.swing.JTextField();
        txt_referenciapedido = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        TxT_nombrepedido = new javax.swing.JTextField();
        TxT_idclientepedido = new javax.swing.JTextField();
        button_cancelarpedido = new javax.swing.JButton();
        button_agregarpedido1 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable_CARRITO_COMPRAS = new javax.swing.JTable();
        jLabel45 = new javax.swing.JLabel();
        txt_idcarrito = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        txt_codclientecarrito = new javax.swing.JTextField();
        jLabel47 = new javax.swing.JLabel();
        txt_codprodcarrito = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        txt_cantidadcarrito = new javax.swing.JTextField();
        jLabel49 = new javax.swing.JLabel();
        txt_preciounitariocarrito = new javax.swing.JTextField();
        txt_subtotalcarrito = new javax.swing.JLabel();
        txt_subtotaldelcarrito = new javax.swing.JTextField();
        txt_subtotalcarrito1 = new javax.swing.JLabel();
        jrbutton_carritoefectivo = new javax.swing.JRadioButton();
        jrbutton_carritotarjeta = new javax.swing.JRadioButton();
        jrbutton_billeteradigitalcarrito = new javax.swing.JRadioButton();
        button_agregaralcarrito = new javax.swing.JButton();
        button_quitardelcarrito = new javax.swing.JButton();
        jLabel50 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable_productosvistacarrito = new javax.swing.JTable();
        txt_subtotalcarrito2 = new javax.swing.JLabel();
        txt_numerotarjeta = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        txt_iddelivery = new javax.swing.JTextField();
        txt_fechadelivery = new javax.swing.JTextField();
        txt_nombreEmpdelivery = new javax.swing.JTextField();
        txt_direccióndeliveryentre = new javax.swing.JTextField();
        txt_referenciadelivery = new javax.swing.JTextField();
        txt_costodelivery = new javax.swing.JTextField();
        txt_telefonoCliente = new javax.swing.JTextField();
        txt_vendedordelivery = new javax.swing.JTextField();
        AGREGAR_DELIVERY = new javax.swing.JButton();
        ELIMINAR_DELIVERY = new javax.swing.JButton();
        jLabel42 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableDelivery = new javax.swing.JTable();
        jLabel44 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        txt_idclientedelivery = new javax.swing.JTextField();
        jPanel10 = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        txt_ID_BOLETA = new javax.swing.JTextField();
        jLabel61 = new javax.swing.JLabel();
        txt_F_EMICION_compo = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        txt_F_VENCIMIENTO_compo = new javax.swing.JTextField();
        txt_ID_VENDEDOR_compo = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        txt_ID_PEDIDO_compo = new javax.swing.JTextField();
        jLabel66 = new javax.swing.JLabel();
        txt_NOMBRE_CLIENTE = new javax.swing.JTextField();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        txt_DNI_compo = new javax.swing.JTextField();
        jLabel69 = new javax.swing.JLabel();
        txt_DIRECCION_compo = new javax.swing.JTextField();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable_COMPROBANTE = new javax.swing.JTable();
        txt_COSTO_DELIVERY_cpmpo = new javax.swing.JTextField();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        txt_IGV_compo = new javax.swing.JTextField();
        txt_TOTAL_PAGAR_compo = new javax.swing.JTextField();
        jButton_INSERTAR_COMPROBANTE = new javax.swing.JButton();
        jLabel70 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        jTextField6.setText("jTextField1");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));

        jButton_EMPRESA.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_EMPRESA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/empresa.png"))); // NOI18N
        jButton_EMPRESA.setText("Empresa");
        jButton_EMPRESA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_EMPRESAActionPerformed(evt);
            }
        });

        jButton_ADMINISTRADOR.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_ADMINISTRADOR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/admi.png"))); // NOI18N
        jButton_ADMINISTRADOR.setText("Administrador");
        jButton_ADMINISTRADOR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ADMINISTRADORActionPerformed(evt);
            }
        });

        jButton_CLIENTES.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_CLIENTES.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/clientes.jpg"))); // NOI18N
        jButton_CLIENTES.setText("Clientes");
        jButton_CLIENTES.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_CLIENTESActionPerformed(evt);
            }
        });

        jButton_VENDEDOR.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_VENDEDOR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/vendedor.png"))); // NOI18N
        jButton_VENDEDOR.setText("Vendedor");
        jButton_VENDEDOR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_VENDEDORActionPerformed(evt);
            }
        });

        jButton_PROVEEDOR.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_PROVEEDOR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/proveedor.png"))); // NOI18N
        jButton_PROVEEDOR.setText("Proveedor");
        jButton_PROVEEDOR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_PROVEEDORActionPerformed(evt);
            }
        });

        jButton_PRODUCTOS_LACTEOS.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_PRODUCTOS_LACTEOS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/leche.jpg"))); // NOI18N
        jButton_PRODUCTOS_LACTEOS.setText("Productos");
        jButton_PRODUCTOS_LACTEOS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_PRODUCTOS_LACTEOSActionPerformed(evt);
            }
        });

        jButton_PEDIDOS.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_PEDIDOS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/pedidos.png"))); // NOI18N
        jButton_PEDIDOS.setText("Pedidos");
        jButton_PEDIDOS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_PEDIDOSActionPerformed(evt);
            }
        });

        jButton_CARRITO_COMPRAS.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_CARRITO_COMPRAS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/carrito.png"))); // NOI18N
        jButton_CARRITO_COMPRAS.setText("Carrito de compras");
        jButton_CARRITO_COMPRAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_CARRITO_COMPRASActionPerformed(evt);
            }
        });

        jButton_DELIVERY.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_DELIVERY.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/delivery.jpg"))); // NOI18N
        jButton_DELIVERY.setText("Delivery");
        jButton_DELIVERY.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_DELIVERYActionPerformed(evt);
            }
        });

        jButton_COMPROBANTE_PAGO.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_COMPROBANTE_PAGO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/factura.png"))); // NOI18N
        jButton_COMPROBANTE_PAGO.setText("Comprobantes");
        jButton_COMPROBANTE_PAGO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_COMPROBANTE_PAGOActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Afiche(2).jpg"))); // NOI18N

        jLabel18.setText("PRODUCTORA");

        jLabel59.setText("CELIS S.R.L");

        Jbutton_CerrarConexion.setText("Cerrar Sesion");
        Jbutton_CerrarConexion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Jbutton_CerrarConexionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(jLabel59))
                            .addComponent(Jbutton_CerrarConexion))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton_COMPROBANTE_PAGO, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton_ADMINISTRADOR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton_EMPRESA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton_CLIENTES, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton_VENDEDOR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton_PROVEEDOR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton_PRODUCTOS_LACTEOS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton_PEDIDOS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton_CARRITO_COMPRAS, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE)
                            .addComponent(jButton_DELIVERY, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(20, 20, 20))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jLabel18)
                        .addGap(2, 2, 2)
                        .addComponent(jLabel59)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Jbutton_CerrarConexion)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton_EMPRESA)
                .addGap(10, 10, 10)
                .addComponent(jButton_ADMINISTRADOR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton_CLIENTES, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton_VENDEDOR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton_PROVEEDOR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton_PRODUCTOS_LACTEOS)
                .addGap(18, 18, 18)
                .addComponent(jButton_PEDIDOS)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton_CARRITO_COMPRAS, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton_DELIVERY)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton_COMPROBANTE_PAGO)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 220, 780));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setForeground(new java.awt.Color(255, 110, 199));

        jLabel3.setFont(new java.awt.Font("Stencil", 1, 18)); // NOI18N
        jLabel3.setText("NOSOTROS");

        jLabel4.setFont(new java.awt.Font("Stencil", 1, 18)); // NOI18N
        jLabel4.setText("MISIÓN");

        jLabel5.setFont(new java.awt.Font("Stencil", 1, 18)); // NOI18N
        jLabel5.setText("VISIÓN");

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Nosotros.png"))); // NOI18N

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Misión.png"))); // NOI18N

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/producto.jpg"))); // NOI18N

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Visión.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(244, 244, 244)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(349, 349, 349))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                        .addGap(19, 19, 19)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(35, 35, 35))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(51, 51, 51))))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 104, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel28))
                .addGap(152, 152, 152))
        );

        Productos.addTab("Empresa", jPanel2);

        jPanel12.setBackground(new java.awt.Color(255, 110, 199));

        jLabel6.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel6.setText("Eliminar administración");

        Jtable_admins.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(Jtable_admins);

        jLabel7.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jLabel7.setText("Ingrese un ID registrado: ");

        jLabel8.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel8.setText("Gerentes y administrativos");

        Button_EliminarAdm.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Button_EliminarAdm.setText("Eliminar");
        Button_EliminarAdm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_EliminarAdmActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel8)
                        .addGroup(jPanel12Layout.createSequentialGroup()
                            .addComponent(TxT_ideliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(41, 41, 41)
                            .addComponent(Button_EliminarAdm, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(376, 376, 376)))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addGap(22, 22, 22)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Button_EliminarAdm, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxT_ideliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(161, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        Productos.addTab("Administracion", jPanel7);

        jPanel21.setBackground(new java.awt.Color(255, 110, 199));

        JtableCli.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane11.setViewportView(JtableCli);

        Clientes.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        Clientes.setText("Clientes:");

        jLabel85.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel85.setText("Productos:");

        jLabel86.setText("ID Cliente: ");

        jLabel87.setText("Nombre:");

        jLabel88.setText("Apellido:");

        jLabel89.setText("DNI:");

        jLabel90.setText("Edad:");

        jLabel91.setText("Numero de teléfono:");

        jLabel92.setText("Tipo_de_cliente:");

        jLabel93.setText("Contraseña:");

        jButton1_AGREGAR_CLIENTES.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1_AGREGAR_CLIENTES.setText("Agregar");
        jButton1_AGREGAR_CLIENTES.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1_AGREGAR_CLIENTESActionPerformed(evt);
            }
        });

        txt_DNIC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_DNICActionPerformed(evt);
            }
        });

        Button_EliminaClientes.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Button_EliminaClientes.setText("Eliminar");
        Button_EliminaClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_EliminaClientesActionPerformed(evt);
            }
        });

        txt_CONTRASEÑAC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_CONTRASEÑACActionPerformed(evt);
            }
        });

        jLabel95.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel95.setText("Género:");

        rbutton_ClienteMasculino.setText("Masculino");

        rbutton_ClienteFemenino.setText("Femenino");
        rbutton_ClienteFemenino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbutton_ClienteFemeninoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel86, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel90)
                            .addComponent(jLabel87, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel88, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txt_APELLIDOC, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                            .addComponent(txt_NOMBREC, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_IDC, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_DNIC, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_EDADC))
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel21Layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel91)
                                    .addComponent(jLabel92)
                                    .addComponent(jLabel93))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_NUMERO_TELEFONICOC, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_CLIENTE_CARGOC, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_CONTRASEÑAC, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(46, 46, 46))
                            .addGroup(jPanel21Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1_AGREGAR_CLIENTES, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(76, 76, 76)))
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Button_EliminaClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rbutton_ClienteFemenino)
                            .addComponent(rbutton_ClienteMasculino)
                            .addComponent(jLabel95))
                        .addGap(43, 43, 43))
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 672, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Clientes)
                            .addComponent(jLabel85)
                            .addComponent(jLabel89, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Clientes, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel86)
                    .addComponent(jLabel91)
                    .addComponent(txt_IDC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_NUMERO_TELEFONICOC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel95))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel87)
                    .addComponent(txt_NOMBREC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_CLIENTE_CARGOC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel92)
                    .addComponent(rbutton_ClienteFemenino))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbutton_ClienteMasculino)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel93)
                        .addComponent(txt_CONTRASEÑAC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel88)
                        .addComponent(txt_APELLIDOC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel89)
                    .addComponent(txt_DNIC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel90)
                    .addComponent(txt_EDADC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1_AGREGAR_CLIENTES, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Button_EliminaClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel85, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(143, 143, 143))
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Productos.addTab("Clientes", jPanel11);

        jPanel22.setBackground(new java.awt.Color(255, 110, 199));

        JtableVendedores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane12.setViewportView(JtableVendedores);

        Empleados.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        Empleados.setText("Empleados");

        jLabel96.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel96.setText("Empleados en Planilla");

        jLabel97.setText("ID del vendedor:");

        jLabel98.setText("Nombre:");

        jLabel99.setText("Apellido:");

        jLabel100.setText("DNI:");

        jLabel101.setText("Edad:");

        jLabel102.setText("Numero de teléfono:");

        jLabel103.setText("Cargo:");

        jLabel104.setText("Contraseña:");

        jbutton_ContratarEmp.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbutton_ContratarEmp.setText("Contratar");
        jbutton_ContratarEmp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbutton_ContratarEmpActionPerformed(evt);
            }
        });

        txt_DNIven.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_DNIvenActionPerformed(evt);
            }
        });

        jbutton_despedirEmp.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbutton_despedirEmp.setText("Despedir");
        jbutton_despedirEmp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbutton_despedirEmpActionPerformed(evt);
            }
        });

        txt_PAGOMENSUALven.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_PAGOMENSUALvenActionPerformed(evt);
            }
        });

        jLabel105.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel105.setText("Género: ");

        rbutton_VendedorMasculino1.setText("Masculino");

        rbutton_VendedorFemenino.setText("Femenino");
        rbutton_VendedorFemenino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbutton_VendedorFemeninoActionPerformed(evt);
            }
        });

        jLabel106.setText("Pago Mensual:");

        txt_CONTRASEÑAven.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_CONTRASEÑAvenActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 672, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Empleados)
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel97)
                                    .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel99, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
                                        .addComponent(jLabel98, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jLabel101, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txt_APELLIDOven, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                                    .addComponent(txt_NOMBREven, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_IDven, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_DNIven, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_EDADven))
                                .addGap(34, 34, 34)
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel103)
                                    .addComponent(jLabel102)
                                    .addComponent(jLabel104)
                                    .addComponent(jLabel106, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel96, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_NUMEROTEven, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_CARGOven, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_CONTRASEÑAven, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(46, 46, 46)
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rbutton_VendedorFemenino)
                                    .addComponent(rbutton_VendedorMasculino1)
                                    .addComponent(jLabel105, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel22Layout.createSequentialGroup()
                                        .addComponent(txt_PAGOMENSUALven, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jbutton_ContratarEmp, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addComponent(jbutton_despedirEmp, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel100, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Empleados, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel97)
                    .addComponent(jLabel102)
                    .addComponent(txt_IDven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_NUMEROTEven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel105))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel98)
                    .addComponent(txt_NOMBREven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_CARGOven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel103)
                    .addComponent(rbutton_VendedorFemenino))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_CONTRASEÑAven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel104)
                        .addComponent(rbutton_VendedorMasculino1))
                    .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel99)
                        .addComponent(txt_APELLIDOven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel100)
                    .addComponent(txt_DNIven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel101)
                    .addComponent(txt_EDADven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel106)
                    .addComponent(txt_PAGOMENSUALven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jbutton_ContratarEmp, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jbutton_despedirEmp, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel96, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(207, 207, 207))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, 592, Short.MAX_VALUE)
                .addContainerGap())
        );

        Productos.addTab("Vendedor", jPanel5);

        jPanel23.setBackground(new java.awt.Color(255, 110, 199));

        jTableProveedor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane13.setViewportView(jTableProveedor);

        Clientes1.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        Clientes1.setText("Proveedores");

        jLabel107.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel107.setText("Proveedores registrados");

        jLabel108.setText("RUC: ");

        jLabel109.setText("Nombre:");

        jLabel110.setText("Apellido:");

        jLabel111.setText("DNI:");

        jLabel112.setText("Edad:");

        jLabel113.setText("Numero de teléfono:");

        jLabel114.setText("Cargo:");

        jLabel115.setText("Contraseña:");

        jbutton_Agregarproveedor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbutton_Agregarproveedor.setText("Agregar");
        jbutton_Agregarproveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbutton_AgregarproveedorActionPerformed(evt);
            }
        });

        txt_dniproveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_dniproveedorActionPerformed(evt);
            }
        });

        jbutton_eliminarproveedor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbutton_eliminarproveedor.setText("Eliminar");
        jbutton_eliminarproveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbutton_eliminarproveedorActionPerformed(evt);
            }
        });

        txt_contraseñaproveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_contraseñaproveedorActionPerformed(evt);
            }
        });

        jLabel116.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel116.setText("Género:");

        rbutton_ProveedorMasculino.setText("Masculino");

        rbutton_ProveedorFemenina.setText("Femenino");
        rbutton_ProveedorFemenina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbutton_ProveedorFemeninaActionPerformed(evt);
            }
        });

        jLabel117.setText("Razón Social:");

        txt_razonsocialproveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_razonsocialproveedorActionPerformed(evt);
            }
        });

        jLabel118.setText("Calidad:");

        txt_calidadproveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_calidadproveedorActionPerformed(evt);
            }
        });

        jLabel119.setText("Lugar de Origen:");

        txt_lugardeorigenproveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_lugardeorigenproveedorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addComponent(Clientes1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel109)
                            .addComponent(jLabel107)
                            .addGroup(jPanel23Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel111, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel112, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel110, javax.swing.GroupLayout.Alignment.LEADING)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel23Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jLabel118)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txt_calidadproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel23Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jLabel116, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(25, 25, 25)
                                .addComponent(rbutton_ProveedorFemenina)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbutton_ProveedorMasculino)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel23Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel23Layout.createSequentialGroup()
                                        .addComponent(jLabel114)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txt_cargoproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel23Layout.createSequentialGroup()
                                        .addComponent(jLabel115)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txt_contraseñaproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel23Layout.createSequentialGroup()
                                        .addComponent(jLabel117)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txt_razonsocialproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel23Layout.createSequentialGroup()
                                        .addComponent(jLabel119)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                                        .addComponent(txt_lugardeorigenproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel23Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel113)
                                .addGap(18, 18, 18)
                                .addComponent(txt_numerotelproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(98, 121, Short.MAX_VALUE))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 672, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel23Layout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addComponent(jLabel108)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txt_nombreproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txt_idproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txt_apellidoproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txt_dniproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txt_edadproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel23Layout.createSequentialGroup()
                                    .addGap(28, 28, 28)
                                    .addComponent(jbutton_Agregarproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(35, 35, 35)
                                    .addComponent(jbutton_eliminarproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 28, Short.MAX_VALUE))))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Clientes1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel108)
                    .addComponent(txt_idproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel113)
                    .addComponent(txt_numerotelproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel109)
                    .addComponent(txt_nombreproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel114)
                    .addComponent(txt_cargoproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel110)
                            .addComponent(txt_apellidoproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel111)
                                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txt_razonsocialproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel117)))
                            .addComponent(txt_dniproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_contraseñaproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel115)))
                .addGap(2, 2, 2)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel23Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(txt_edadproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txt_lugardeorigenproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel119))))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel112)))
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel118)
                            .addComponent(txt_calidadproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rbutton_ProveedorFemenina)
                            .addComponent(rbutton_ProveedorMasculino)
                            .addComponent(jLabel116)))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 106, Short.MAX_VALUE)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jbutton_Agregarproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbutton_eliminarproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addComponent(jLabel107, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(93, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jPanel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Productos.addTab("Proveedor", jPanel4);

        jPanel14.setBackground(new java.awt.Color(255, 110, 199));

        Jtable_productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(Jtable_productos);

        jLabel17.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel17.setText("Agregar Producto:");

        jLabel19.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel19.setText("Productos:");

        jLabel12.setText("ID del producto: ");

        jLabel13.setText("Nombre del producto:");

        jLabel14.setText("Descripcion:");

        jLabel15.setText("Stock de producto:");

        jLabel16.setText("Fecha de vencimiento: ");

        jLabel20.setText("Precio unitario:");

        jLabel21.setText("Descuento:");

        jLabel22.setText("ID del proveedor:");

        Button_RegistrarProducto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Button_RegistrarProducto.setText("Agregar");
        Button_RegistrarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_RegistrarProductoActionPerformed(evt);
            }
        });

        Button_EliminarProducto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Button_EliminarProducto.setText("Eliminar");
        Button_EliminarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_EliminarProductoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 672, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel17)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_idelproducto, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_nombredelproducto, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_stock, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(78, 78, 78)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_idproveedorProd, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_descuento, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_preciounitarioproduc, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel19))
                .addContainerGap(28, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Button_RegistrarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(Button_EliminarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(87, 87, 87))
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jLabel16)
                .addGap(18, 18, 18)
                .addComponent(txt_fechadevencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel20)
                    .addComponent(txt_idelproducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_preciounitarioproduc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(txt_nombredelproducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_descuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22)
                    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel14)
                        .addComponent(txt_descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_idproveedorProd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(txt_stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txt_fechadevencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Button_RegistrarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Button_EliminarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        Productos.addTab("Productos", jPanel3);

        jPanel15.setBackground(new java.awt.Color(255, 110, 199));

        Jtable_pedidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(Jtable_pedidos);

        jLabel26.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel26.setText("Registrar Pedidos");

        jLabel27.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel27.setText("Pedidos");

        jLabel29.setText("Descripcion del pedido:");

        jLabel37.setText("ID del Cliente:");

        jLabel38.setText("ID del Vendedor: ");

        TxT_descripcionpedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxT_descripcionpedidoActionPerformed(evt);
            }
        });

        jLabel30.setText("Fecha del pedido:");

        jLabel31.setText("Direccion del pedido:");

        jLabel32.setText("Referencia: ");

        jLabel33.setText("Codigo de pedido:");

        jLabel34.setText("Nombre del pedido:");

        button_cancelarpedido.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        button_cancelarpedido.setText("Cancelar Pedido");
        button_cancelarpedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_cancelarpedidoActionPerformed(evt);
            }
        });

        button_agregarpedido1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        button_agregarpedido1.setText("Agendar Pedido");
        button_agregarpedido1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_agregarpedido1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 672, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel29)
                                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel37, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel38, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TxT_nombrepedido, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxT_descripcionpedido, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxT_codigopedido, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxT_idclientepedido, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxT_idvendedorpedido, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel27))
                        .addGap(45, 45, 45)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addComponent(button_agregarpedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(button_cancelarpedido, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_referenciapedido, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel15Layout.createSequentialGroup()
                                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(TxT_Direciconpedido, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel15Layout.createSequentialGroup()
                                    .addComponent(jLabel30)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txt_fechaped, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addComponent(jLabel26)
                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxT_codigopedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_fechaped, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel33)
                    .addComponent(jLabel30))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(TxT_nombrepedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31)
                    .addComponent(TxT_Direciconpedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel29)
                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(TxT_descripcionpedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel32)
                        .addComponent(txt_referenciapedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxT_idclientepedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel37))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TxT_idvendedorpedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel38)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(button_cancelarpedido, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(button_agregarpedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(92, 92, 92))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        Productos.addTab("Pedidos", jPanel6);

        jPanel8.setBackground(new java.awt.Color(255, 110, 199));

        jLabel43.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jLabel43.setText("Productos Disponibles");

        jLabel51.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jLabel51.setText("Productos en el carrito");

        jTable_CARRITO_COMPRAS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(jTable_CARRITO_COMPRAS);

        jLabel45.setText("Codigo de carrito:");

        jLabel46.setText("Codigo del cliente:");

        jLabel47.setText("Codigo del producto:");

        jLabel48.setText("Cantidad:");

        jLabel49.setText("Precio Unitario:");

        txt_subtotalcarrito.setText("SubTotal:");

        txt_subtotalcarrito1.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        txt_subtotalcarrito1.setText("Método de Pago:");

        jrbutton_carritoefectivo.setText("Efectivo");

        jrbutton_carritotarjeta.setText("Tarjeta ");

        jrbutton_billeteradigitalcarrito.setText("Billetera Digital");

        button_agregaralcarrito.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        button_agregaralcarrito.setText("Agregar");
        button_agregaralcarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_agregaralcarritoActionPerformed(evt);
            }
        });

        button_quitardelcarrito.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        button_quitardelcarrito.setText("Quitar");
        button_quitardelcarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_quitardelcarritoActionPerformed(evt);
            }
        });

        jLabel50.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jLabel50.setText("Tu carrito de compras");

        jTable_productosvistacarrito.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane7.setViewportView(jTable_productosvistacarrito);

        txt_subtotalcarrito2.setText("Número Tarjeta:");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel51, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(122, 122, 122))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 654, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(34, Short.MAX_VALUE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel45)
                        .addGap(23, 23, 23)
                        .addComponent(txt_idcarrito, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel48)
                                .addGap(67, 67, 67)
                                .addComponent(txt_cantidadcarrito))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel47)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_codprodcarrito))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel46)
                                .addGap(18, 18, 18)
                                .addComponent(txt_codclientecarrito, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel49)
                                    .addComponent(txt_subtotalcarrito))
                                .addGap(36, 36, 36)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_subtotaldelcarrito)
                                    .addComponent(txt_preciounitariocarrito))))
                        .addGap(43, 43, 43)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_subtotalcarrito1)
                                    .addComponent(jrbutton_billeteradigitalcarrito)
                                    .addComponent(jrbutton_carritoefectivo)
                                    .addComponent(jrbutton_carritotarjeta))
                                .addGap(21, 21, 21)
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txt_subtotalcarrito2)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(txt_numerotarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(button_agregaralcarrito, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(button_quitardelcarrito, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))))))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(40, 40, 40)
                    .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(450, Short.MAX_VALUE)))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel45)
                            .addComponent(txt_idcarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_subtotalcarrito1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel46)
                            .addComponent(txt_codclientecarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jrbutton_carritoefectivo))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel47)
                            .addComponent(txt_codprodcarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jrbutton_carritotarjeta))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel48)
                            .addComponent(txt_cantidadcarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jrbutton_billeteradigitalcarrito)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel43)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel49)
                    .addComponent(txt_preciounitariocarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_subtotalcarrito2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_subtotalcarrito)
                    .addComponent(txt_subtotaldelcarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_numerotarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button_agregaralcarrito)
                    .addComponent(button_quitardelcarrito))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel51)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(166, Short.MAX_VALUE))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(25, 25, 25)
                    .addComponent(jLabel50)
                    .addContainerGap(549, Short.MAX_VALUE)))
        );

        Productos.addTab("Carrito de compras", jPanel8);

        jPanel9.setBackground(new java.awt.Color(255, 110, 199));

        jLabel23.setText("N° :");

        jLabel24.setText("Fecha:");

        jLabel25.setText("Empresa:");

        jLabel35.setText("Dirección a entregar:");

        jLabel36.setText("Costo de envío:");

        jLabel39.setText("Teléfono Cliente:");

        jLabel40.setText("Cod del vendedor:");

        jLabel41.setText("Referencia:");

        txt_iddelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_iddeliveryActionPerformed(evt);
            }
        });

        txt_nombreEmpdelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nombreEmpdeliveryActionPerformed(evt);
            }
        });

        txt_direccióndeliveryentre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_direccióndeliveryentreActionPerformed(evt);
            }
        });

        txt_referenciadelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_referenciadeliveryActionPerformed(evt);
            }
        });

        txt_vendedordelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_vendedordeliveryActionPerformed(evt);
            }
        });

        AGREGAR_DELIVERY.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        AGREGAR_DELIVERY.setText("AGREGAR");
        AGREGAR_DELIVERY.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AGREGAR_DELIVERYActionPerformed(evt);
            }
        });

        ELIMINAR_DELIVERY.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ELIMINAR_DELIVERY.setText("ELIMINAR");
        ELIMINAR_DELIVERY.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ELIMINAR_DELIVERYActionPerformed(evt);
            }
        });

        jLabel42.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jLabel42.setText("REGISTRO DEL DELIVERY");

        jTableDelivery.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTableDelivery);

        jLabel44.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jLabel44.setText("MOSTRAR DELIVERY");

        jLabel52.setText("ID del cliente:");

        txt_idclientedelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_idclientedeliveryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 255, Short.MAX_VALUE)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel9Layout.createSequentialGroup()
                                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel39)
                                            .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txt_vendedordelivery, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txt_telefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel9Layout.createSequentialGroup()
                                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel36))
                                        .addGap(40, 40, 40)
                                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txt_referenciadelivery, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel9Layout.createSequentialGroup()
                                                .addComponent(txt_costodelivery)
                                                .addGap(38, 38, 38)))))
                                .addGap(104, 104, 104))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel23, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel52)
                                    .addComponent(jLabel35))
                                .addGap(35, 35, 35)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel9Layout.createSequentialGroup()
                                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txt_fechadelivery, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txt_nombreEmpdelivery, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txt_iddelivery, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txt_direccióndeliveryentre, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanel9Layout.createSequentialGroup()
                                        .addComponent(txt_idclientedelivery, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 535, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(AGREGAR_DELIVERY)
                .addGap(33, 33, 33)
                .addComponent(ELIMINAR_DELIVERY)
                .addGap(96, 96, 96))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                            .addGap(17, 17, 17)
                            .addComponent(jLabel42)
                            .addGap(18, 18, 18)
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txt_iddelivery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel41)
                                .addComponent(txt_referenciadelivery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel23))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txt_fechadelivery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel36)
                                .addComponent(txt_costodelivery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel9Layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txt_nombreEmpdelivery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel9Layout.createSequentialGroup()
                                    .addGap(9, 9, 9)
                                    .addComponent(txt_vendedordelivery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(jPanel9Layout.createSequentialGroup()
                            .addGap(95, 95, 95)
                            .addComponent(jLabel24)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel25)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel40)
                        .addGap(5, 5, 5)))
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel35)
                            .addComponent(txt_direccióndeliveryentre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_idclientedelivery, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel52))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 121, Short.MAX_VALUE)
                        .addComponent(jLabel44))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jLabel39))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(txt_telefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(67, 67, 67)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ELIMINAR_DELIVERY)
                            .addComponent(AGREGAR_DELIVERY))
                        .addGap(0, 93, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81))
        );

        Productos.addTab("Delivery", jPanel9);

        jPanel10.setBackground(new java.awt.Color(255, 153, 204));

        jLabel53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Afiche (3).jpg"))); // NOI18N
        jLabel53.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel54.setFont(new java.awt.Font("Segoe Print", 0, 8)); // NOI18N
        jLabel54.setText("R.U.C.: 261014789312");

        jLabel55.setFont(new java.awt.Font("Segoe Print", 0, 10)); // NOI18N
        jLabel55.setText("Av.Bolognesi(128) San Miguel-Cajamarca");

        jLabel56.setFont(new java.awt.Font("Segoe Print", 0, 8)); // NOI18N
        jLabel56.setText("Telf: 982317561");

        jLabel57.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel57.setText("BOLETA DE VENTA");

        jLabel58.setText("N° :");

        jLabel60.setText("F.Emisión  :");

        jLabel61.setText("Moneda   :");

        jLabel62.setText("F.Venc       :");

        jLabel63.setText("Soles");

        jLabel64.setText("Vendedor:");

        jLabel65.setText("N° Pedido: ");

        jLabel66.setText("Nombre:");

        jLabel67.setText("DNI : ");

        jLabel68.setFont(new java.awt.Font("Segoe Print", 1, 10)); // NOI18N
        jLabel68.setText("\"Productora Celis S.R.L.\"");

        txt_DNI_compo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_DNI_compoActionPerformed(evt);
            }
        });

        jLabel69.setText("Dirección :");

        jTable_COMPROBANTE.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Código", "Nombre", "Descripción", "Cantidad", "Precio", "Descuento", "Importe"
            }
        ));
        jScrollPane8.setViewportView(jTable_COMPROBANTE);

        jLabel72.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel72.setText("Comprobantes - Registro SUNAT");

        jLabel73.setText("Costo de delivery: ");

        jLabel74.setText("IGV:");

        jLabel75.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel75.setText("Total a pagar:");

        txt_IGV_compo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_IGV_compoActionPerformed(evt);
            }
        });

        jButton_INSERTAR_COMPROBANTE.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_INSERTAR_COMPROBANTE.setText("INSERTAR");
        jButton_INSERTAR_COMPROBANTE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_INSERTAR_COMPROBANTEActionPerformed(evt);
            }
        });

        jLabel70.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel70.setText("Detalles del cliente:");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(138, 138, 138)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_NOMBRE_CLIENTE, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_DNI_compo, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(97, 97, 97)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_F_EMICION_compo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_F_VENCIMIENTO_compo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_COSTO_DELIVERY_cpmpo, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel73)))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jLabel65, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
                                            .addComponent(jLabel64, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(18, 18, 18)
                                        .addComponent(txt_ID_PEDIDO_compo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(80, 80, 80)
                                        .addComponent(txt_IGV_compo, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(50, 50, 50))
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addComponent(jLabel75, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txt_TOTAL_PAGAR_compo, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(70, 70, 70)))))
                        .addGap(37, 37, 37))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel63, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_ID_VENDEDOR_compo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel74, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(92, 92, 92))))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jLabel67, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(jLabel70)))
                .addGap(7, 7, 7)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addComponent(jLabel57, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                        .addGap(284, 284, 284)
                        .addComponent(jLabel58, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txt_ID_BOLETA)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 554, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(51, 51, 51)
                                .addComponent(jButton_INSERTAR_COMPROBANTE, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addGap(74, 74, 74)
                                        .addComponent(jLabel56, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel55))
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addGap(63, 63, 63)
                                        .addComponent(jLabel54))
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addGap(54, 54, 54)
                                        .addComponent(jLabel68, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jLabel66)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel69, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(21, 21, 21)
                                .addComponent(txt_DIRECCION_compo, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel10Layout.createSequentialGroup()
                            .addComponent(jLabel72)
                            .addGap(156, 156, 156))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel57)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel58)
                                    .addComponent(txt_ID_BOLETA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel68)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel55)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel54)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel56))
                    .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel70)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txt_F_VENCIMIENTO_compo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel62))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel61)
                                    .addComponent(jLabel63))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel64)
                                    .addComponent(txt_ID_VENDEDOR_compo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel66, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_NOMBRE_CLIENTE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel67)
                                    .addComponent(txt_DNI_compo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel69)
                                    .addComponent(txt_DIRECCION_compo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel65)
                            .addComponent(txt_ID_PEDIDO_compo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel60)
                                .addComponent(txt_F_EMICION_compo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel73))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_COSTO_DELIVERY_cpmpo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel74)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_IGV_compo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)))
                .addComponent(jButton_INSERTAR_COMPROBANTE, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel75)
                    .addComponent(txt_TOTAL_PAGAR_compo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel72))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(93, Short.MAX_VALUE))
        );

        Productos.addTab("Comprobantes", jPanel10);

        getContentPane().add(Productos, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 180, 700, 580));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Página.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 0, 710, 180));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_COMPROBANTE_PAGOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_COMPROBANTE_PAGOActionPerformed
        Productos.setSelectedIndex(9);
    }//GEN-LAST:event_jButton_COMPROBANTE_PAGOActionPerformed

    private void jButton_DELIVERYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_DELIVERYActionPerformed
        Productos.setSelectedIndex(8);
    }//GEN-LAST:event_jButton_DELIVERYActionPerformed

    private void jButton_CARRITO_COMPRASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_CARRITO_COMPRASActionPerformed
        Productos.setSelectedIndex(7);
    }//GEN-LAST:event_jButton_CARRITO_COMPRASActionPerformed

    private void jButton_PEDIDOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_PEDIDOSActionPerformed
        // TODO add your handling code here:
        Productos.setSelectedIndex(6);
    }//GEN-LAST:event_jButton_PEDIDOSActionPerformed

    private void jButton_PRODUCTOS_LACTEOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_PRODUCTOS_LACTEOSActionPerformed
        Productos.setSelectedIndex(5);
    }//GEN-LAST:event_jButton_PRODUCTOS_LACTEOSActionPerformed

    private void jButton_PROVEEDORActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_PROVEEDORActionPerformed
        Productos.setSelectedIndex(4);
    }//GEN-LAST:event_jButton_PROVEEDORActionPerformed

    private void jButton_VENDEDORActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_VENDEDORActionPerformed
        Productos.setSelectedIndex(3);
    }//GEN-LAST:event_jButton_VENDEDORActionPerformed

    private void jButton_CLIENTESActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_CLIENTESActionPerformed
        Productos.setSelectedIndex(2);
    }//GEN-LAST:event_jButton_CLIENTESActionPerformed

    private void jButton_ADMINISTRADORActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ADMINISTRADORActionPerformed
        Productos.setSelectedIndex(1);
    }//GEN-LAST:event_jButton_ADMINISTRADORActionPerformed

    private void jButton_EMPRESAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_EMPRESAActionPerformed
        Productos.setSelectedIndex(0);
    }//GEN-LAST:event_jButton_EMPRESAActionPerformed

    private void Button_EliminarAdmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_EliminarAdmActionPerformed
        int ID;
        ID = Integer.parseInt(TxT_ideliminar.getText());

        Administracion adElim = new Administracion(ID);

        int elim = modelAdm.eliminar(adElim);

        if (elim == 1) {
            JOptionPane.showMessageDialog(this, "Se elimino de manera correcta!");
            TxT_ideliminar.setText("");
        } else {

            JOptionPane.showMessageDialog(this, "Error al encontrar al administrador!");
        }

        mostrarAdmins();
    }//GEN-LAST:event_Button_EliminarAdmActionPerformed

    private void Button_RegistrarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_RegistrarProductoActionPerformed
        int ID, STOCK, ID_PROVEEDOR;
        String NOMBRE, DESCRIPCION, FECHA_VENCIMIENTO;
        float PRECIO_UNITARIO, DESCUENTO;

        ID = Integer.parseInt(txt_idelproducto.getText());
        NOMBRE = txt_nombredelproducto.getText();
        DESCRIPCION = txt_descripcion.getText();
        STOCK = Integer.parseInt(txt_stock.getText());
        FECHA_VENCIMIENTO = txt_fechadevencimiento.getText();
        PRECIO_UNITARIO = Float.parseFloat(txt_preciounitarioproduc.getText());
        DESCUENTO = Float.parseFloat(txt_descuento.getText());
        ID_PROVEEDOR = Integer.parseInt(txt_idproveedorProd.getText());

        Producto pr1 = new Producto(ID, NOMBRE, DESCRIPCION, STOCK, FECHA_VENCIMIENTO, PRECIO_UNITARIO, DESCUENTO, ID_PROVEEDOR);

        int r = modelPro.insertar(pr1);
        if (r == 1) {
            JOptionPane.showMessageDialog(this, "Producto registrado !!!");
            txt_idelproducto.setText("");
            txt_nombredelproducto.setText("");
            txt_descripcion.setText("");
            txt_stock.setText("");
            txt_fechadevencimiento.setText("");
            txt_preciounitarioproduc.setText("");
            txt_descuento.setText("");
            txt_idproveedorProd.setText("");
        } else {

            JOptionPane.showMessageDialog(this, "Error al ingresar el producto!!");
        }

        mostrarProductos();

    }//GEN-LAST:event_Button_RegistrarProductoActionPerformed

    private void TxT_descripcionpedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxT_descripcionpedidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxT_descripcionpedidoActionPerformed

    private void button_agregarpedido1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_agregarpedido1ActionPerformed
        int ID, VENDEDOR_ID, CLIENTE_ID;
        String NOMBRE, DESCRIPCION, FECHA_VENCIMIENTO, DIRECCION, REFERENCIA;

        ID = Integer.parseInt(TxT_codigopedido.getText());
        NOMBRE = TxT_nombrepedido.getText();
        DESCRIPCION = TxT_descripcionpedido.getText();
        FECHA_VENCIMIENTO = txt_fechaped.getText();
        DIRECCION = TxT_Direciconpedido.getText();
        REFERENCIA = txt_referenciapedido.getText();
        VENDEDOR_ID = Integer.parseInt(TxT_idvendedorpedido.getText());
        CLIENTE_ID = Integer.parseInt(TxT_idclientepedido.getText());

        Pedidos p1 = new Pedidos(VENDEDOR_ID, CLIENTE_ID, DIRECCION, REFERENCIA, ID, NOMBRE, DESCRIPCION, ABORT, FECHA_VENCIMIENTO, LEFT_ALIGNMENT, TOP_ALIGNMENT, PROPERTIES);

        int r = modelPed.insertar(p1);
        if (r == 1) {
            JOptionPane.showMessageDialog(this, "Pedido Listo.");
            TxT_codigopedido.setText("");
            TxT_nombrepedido.setText("");
            TxT_descripcionpedido.setText("");
            txt_fechaped.setText("");
            TxT_Direciconpedido.setText("");
            txt_referenciapedido.setText("");
            TxT_idvendedorpedido.setText("");
            TxT_idclientepedido.setText("");
        } else {

            JOptionPane.showMessageDialog(this, "Error al ingresar el pedido!!");
        }

        mostrarPedidos();
    }//GEN-LAST:event_button_agregarpedido1ActionPerformed

    private void jButton1_AGREGAR_CLIENTESActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1_AGREGAR_CLIENTESActionPerformed
        int ID, NUMERO_TELEFONO;
        String NOMBRES, APELLIDOS, EDAD, DNI, GENERO, CARGO, CONTRASENIA;

        ID = Integer.parseInt(txt_IDC.getText());
        NOMBRES = txt_NOMBREC.getText();
        APELLIDOS = txt_APELLIDOC.getText();
        DNI = txt_DNIC.getText();
        EDAD = txt_EDADC.getText();
        NUMERO_TELEFONO = Integer.parseInt(txt_NUMERO_TELEFONICOC.getText());
        CARGO = txt_CLIENTE_CARGOC.getText();
        CONTRASENIA = txt_CONTRASEÑAC.getText();

        if (rbutton_ClienteFemenino.isSelected()) {
            GENERO = "Femenino";
        } else {
            GENERO = "Masculino";
        }

        Clientes cli = new Clientes(ID, NOMBRES, APELLIDOS, DNI, EDAD, NUMERO_TELEFONO, GENERO, CARGO, CONTRASENIA);
        int r = modelCli.insertar(cli);
        if (r == 1) {
            JOptionPane.showMessageDialog(this, "Cliente Registrado.");

            txt_IDC.setText("");
            txt_NOMBREC.setText("");
            txt_APELLIDOC.setText("");
            txt_DNIC.setText("");
            txt_EDADC.setText("");
            txt_NUMERO_TELEFONICOC.setText("");
            txt_CLIENTE_CARGOC.setText("");
            txt_CONTRASEÑAC.setText("");

            rbutton_ClienteFemenino.setSelected(false);
            rbutton_ClienteMasculino.setSelected(false);
        } else {

            JOptionPane.showMessageDialog(this, "Error al registrar!");
        }
        mostrarClientes();
    }//GEN-LAST:event_jButton1_AGREGAR_CLIENTESActionPerformed

    private void button_cancelarpedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_cancelarpedidoActionPerformed
        int ID = Integer.parseInt(TxT_codigopedido.getText());

        Pedidos p2 = new Pedidos(ID);
        int r = modelPed.eliminar(p2);
        if (r == 1) {
            JOptionPane.showMessageDialog(this, "Pedido Retirado.");
            TxT_codigopedido.setText("");
        } else {

            JOptionPane.showMessageDialog(this, "Error al retirar el pedido!!");
        }

        mostrarPedidos();
    }//GEN-LAST:event_button_cancelarpedidoActionPerformed

    private void txt_DNICActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_DNICActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_DNICActionPerformed

    private void txt_CONTRASEÑACActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_CONTRASEÑACActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_CONTRASEÑACActionPerformed

    private void rbutton_ClienteFemeninoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbutton_ClienteFemeninoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbutton_ClienteFemeninoActionPerformed

    private void Button_EliminaClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_EliminaClientesActionPerformed
        int ID;
        ID = Integer.parseInt(txt_IDC.getText());

        Clientes clElim = new Clientes(ID);

        int elim = modelCli.eliminar(clElim);

        if (elim == 1) {
            JOptionPane.showMessageDialog(this, "Cliente eliminado correctamente");
            txt_IDC.setText("");
        } else {

            JOptionPane.showMessageDialog(this, "El ID ingresado es incorrecto");
        }

        mostrarClientes();

    }//GEN-LAST:event_Button_EliminaClientesActionPerformed

    private void jbutton_ContratarEmpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbutton_ContratarEmpActionPerformed
        int ID, NUMERO_TELEFONO;
        String NOMBRES, APELLIDOS, DNI, EDAD, GENERO, CARGO, CONTRASENIA;
        float PAGO_MENSUAL;

        ID = Integer.parseInt(txt_IDven.getText());
        NOMBRES = txt_NOMBREven.getText();
        APELLIDOS = txt_APELLIDOven.getText();
        DNI = txt_DNIven.getText();
        EDAD = txt_EDADven.getText();
        NUMERO_TELEFONO = Integer.parseInt(txt_NUMEROTEven.getText());
        CARGO = txt_CARGOven.getText();
        CONTRASENIA = txt_CONTRASEÑAven.getText();
        PAGO_MENSUAL = Float.parseFloat(txt_PAGOMENSUALven.getText());

        if (rbutton_VendedorFemenino.isSelected()) {
            GENERO = "Femenino";
        } else {
            GENERO = "Masculino";
        }

        Vendedores ven = new Vendedores(PAGO_MENSUAL, ID, NOMBRES, APELLIDOS, DNI, EDAD, NUMERO_TELEFONO, GENERO, CARGO, CONTRASENIA);
        int r = modelVen.insertar(ven);
        if (r == 1) {
            JOptionPane.showMessageDialog(this, "Contratado!");
            txt_IDven.setText("");
            txt_NOMBREven.setText("");
            txt_APELLIDOven.setText("");
            txt_DNIven.setText("");
            txt_EDADven.setText("");
            txt_NUMEROTEven.setText("");
            txt_CARGOven.setText("");
            txt_CONTRASEÑAven.setText("");
            txt_PAGOMENSUALven.setText("");
            rbutton_VendedorFemenino.setSelected(false);
            rbutton_VendedorMasculino1.setSelected(false);
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo contratar");
        }

        Mostrar_Vendedores();
    }//GEN-LAST:event_jbutton_ContratarEmpActionPerformed

    private void txt_DNIvenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_DNIvenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_DNIvenActionPerformed

    private void jbutton_despedirEmpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbutton_despedirEmpActionPerformed
        int ID;
        ID = Integer.parseInt(txt_IDven.getText());

        Vendedores Elimvendedor = new Vendedores(ID);

        int elim = modelVen.eliminar(Elimvendedor);

        if (elim == 1) {
            JOptionPane.showMessageDialog(this, "Se elimino de manera correcta!");
            txt_IDven.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Error al encontrar al empleado!");

        }
        Mostrar_Vendedores();
    }//GEN-LAST:event_jbutton_despedirEmpActionPerformed

    private void txt_PAGOMENSUALvenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_PAGOMENSUALvenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_PAGOMENSUALvenActionPerformed

    private void rbutton_VendedorFemeninoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbutton_VendedorFemeninoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbutton_VendedorFemeninoActionPerformed

    private void txt_CONTRASEÑAvenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_CONTRASEÑAvenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_CONTRASEÑAvenActionPerformed

    private void Button_EliminarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_EliminarProductoActionPerformed
        int ID;
        ID = Integer.parseInt(txt_idelproducto.getText());

        Producto prodElim = new Producto(ID);

        int elim = modelPro.eliminar(prodElim);

        if (elim == 1) {
            JOptionPane.showMessageDialog(this, "Se elimino de manera correcta!");
            txt_idelproducto.setText("");
        } else {

            JOptionPane.showMessageDialog(this, "Error al encontrar el producto!");
        }

        mostrarAdmins();
    }//GEN-LAST:event_Button_EliminarProductoActionPerformed

    private void jbutton_AgregarproveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbutton_AgregarproveedorActionPerformed
        int ID, NUMERO_TELEFONO;
        String NOMBRES, APELLIDOS, DNI, EDAD, GENERO, CARGO, CONTRASENIA, RAZON_SOCIAL, LUGAR_DE_ORIGEN, CALIDAD;
        ID = Integer.parseInt(txt_idproveedor.getText());
        NOMBRES = txt_nombreproveedor.getText();
        APELLIDOS = txt_apellidoproveedor.getText();
        DNI = txt_dniproveedor.getText();
        EDAD = txt_edadproveedor.getText();
        NUMERO_TELEFONO = Integer.parseInt(txt_numerotelproveedor.getText());
        CARGO = txt_cargoproveedor.getText();
        CONTRASENIA = txt_contraseñaproveedor.getText();
        RAZON_SOCIAL = txt_razonsocialproveedor.getText();
        LUGAR_DE_ORIGEN = txt_lugardeorigenproveedor.getText();
        CALIDAD = txt_calidadproveedor.getText();

        if (rbutton_ProveedorFemenina.isSelected()) {
            GENERO = "Femenino";
        } else {
            GENERO = "Masculino";
        }

        Proveedores prov = new Proveedores(RAZON_SOCIAL, LUGAR_DE_ORIGEN, CALIDAD, ID, NOMBRES, APELLIDOS, DNI, EDAD, NUMERO_TELEFONO, GENERO, CARGO, CONTRASENIA);
        int r = modelProv.insertar(prov);

        if (r == 1) {
            JOptionPane.showMessageDialog(this, "Proveedor agregado de manera correcta!");
            txt_idproveedor.setText("");
            txt_nombreproveedor.setText("");
            txt_apellidoproveedor.setText("");
            txt_dniproveedor.setText("");
            txt_edadproveedor.setText("");
            txt_numerotelproveedor.setText("");
            txt_cargoproveedor.setText("");
            txt_contraseñaproveedor.setText("");
            txt_razonsocialproveedor.setText("");
            txt_lugardeorigenproveedor.setText("");
            txt_calidadproveedor.setText("");

            // Desseleccionar los botones de opción después de agregar el proveedor
            rbutton_ProveedorFemenina.setSelected(false);
            rbutton_ProveedorMasculino.setSelected(false);
        } else {

            JOptionPane.showMessageDialog(this, "Error al agregar!");
        }
        mostrarProveedores();
    }//GEN-LAST:event_jbutton_AgregarproveedorActionPerformed

    private void txt_dniproveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_dniproveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_dniproveedorActionPerformed

    private void jbutton_eliminarproveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbutton_eliminarproveedorActionPerformed
        int ID = Integer.parseInt(txt_idproveedor.getText());

        Proveedores prElim = new Proveedores(ID);

        int elim = modelProv.eliminar(prElim);

        if (elim == 1) {
            JOptionPane.showMessageDialog(this, "Proveedor eliminado correctamente");
            txt_idproveedor.setText("");
        } else {

            JOptionPane.showMessageDialog(this, "El ID ingresado es incorrecto");
        }
        mostrarProveedores();
    }//GEN-LAST:event_jbutton_eliminarproveedorActionPerformed

    private void txt_contraseñaproveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_contraseñaproveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_contraseñaproveedorActionPerformed

    private void rbutton_ProveedorFemeninaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbutton_ProveedorFemeninaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbutton_ProveedorFemeninaActionPerformed

    private void txt_razonsocialproveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_razonsocialproveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_razonsocialproveedorActionPerformed

    private void txt_calidadproveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_calidadproveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_calidadproveedorActionPerformed

    private void txt_lugardeorigenproveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_lugardeorigenproveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_lugardeorigenproveedorActionPerformed

    private void AGREGAR_DELIVERYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AGREGAR_DELIVERYActionPerformed
        // TODO add your handling code here:
        int ID, TELEFONO, ID_VENDEDOR, ID_CLIENTE;
        String FECHA, NOMBRE, DIRECCION_ENTREGA, REFERENCIA;
        float COSTO_ENVIO;

        ID = Integer.parseInt(txt_iddelivery.getText());
        FECHA = txt_fechadelivery.getText();
        NOMBRE = txt_nombreEmpdelivery.getText();
        DIRECCION_ENTREGA = txt_direccióndeliveryentre.getText();
        REFERENCIA = txt_referenciadelivery.getText();
        TELEFONO = Integer.parseInt(txt_telefonoCliente.getText());
        COSTO_ENVIO = Float.parseFloat(txt_costodelivery.getText());
        ID_VENDEDOR = Integer.parseInt(txt_vendedordelivery.getText());
        ID_CLIENTE = Integer.parseInt(txt_idclientedelivery.getText());

        Delivery del = new Delivery(ID, FECHA, NOMBRE, DIRECCION_ENTREGA, REFERENCIA, COSTO_ENVIO, TELEFONO, ID_VENDEDOR, ID_CLIENTE);
        int r = modelDel.insertar(del);

        if (r == 1) {
            JOptionPane.showMessageDialog(this, "Delivery agregado de manera correcta!");
            txt_iddelivery.setText("");
            txt_fechadelivery.setText("");
            txt_nombreEmpdelivery.setText("");
            txt_direccióndeliveryentre.setText("");
            txt_referenciadelivery.setText("");
            txt_telefonoCliente.setText("");
            txt_costodelivery.setText("");
            txt_vendedordelivery.setText("");
            txt_idclientedelivery.setText("");
        } else {

            JOptionPane.showMessageDialog(this, "Error al agregar!");
        }
        MostrarDelivery();


    }//GEN-LAST:event_AGREGAR_DELIVERYActionPerformed

    private void ELIMINAR_DELIVERYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ELIMINAR_DELIVERYActionPerformed
        int ID = Integer.parseInt(txt_iddelivery.getText());

        Delivery deElim = new Delivery(ID);

        int elim = modelDel.eliminar(deElim);

        if (elim == 1) {
            JOptionPane.showMessageDialog(this, "Delivery eliminado correctamente");
            txt_iddelivery.setText("");
        } else {

            JOptionPane.showMessageDialog(this, "El delivery ingresado es incorrecto");
        }
        MostrarDelivery();

    }//GEN-LAST:event_ELIMINAR_DELIVERYActionPerformed

    private void txt_iddeliveryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_iddeliveryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_iddeliveryActionPerformed

    private void txt_referenciadeliveryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_referenciadeliveryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_referenciadeliveryActionPerformed

    private void button_quitardelcarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_quitardelcarritoActionPerformed
        int ID = Integer.parseInt(txt_idcarrito.getText());

        Carrito_de_compras carrito = new Carrito_de_compras(ID);

        int elim = modelCar.eliminar(carrito);

        if (elim == 1) {
            JOptionPane.showMessageDialog(this, "Se elimino la orden");
            txt_idcarrito.setText("");
        } else {

            JOptionPane.showMessageDialog(this, "Error al eliminar");
        }
        MostrarCarrito();
        mostrarProductos();
    }//GEN-LAST:event_button_quitardelcarritoActionPerformed

    private void button_agregaralcarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_agregaralcarritoActionPerformed
        int ID, ID_CLIENTE, ID_PRODUCTO, CANTIDAD;
        float PRECIO_UNITARIO, SUBTOTAL;
        String METODO_PAGO, NUMERO_TARJETA;

        try {
            CANTIDAD = Integer.parseInt(txt_cantidadcarrito.getText());

            PRECIO_UNITARIO = Float.parseFloat(txt_preciounitariocarrito.getText());

            SUBTOTAL = CANTIDAD * PRECIO_UNITARIO;

            txt_subtotaldelcarrito.setText(String.valueOf(SUBTOTAL));

        } catch (NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Por favor, ingrese cantidades y precios válidos.");
            return;
        }

        ID = Integer.parseInt(txt_idcarrito.getText());
        ID_CLIENTE = Integer.parseInt(txt_codclientecarrito.getText());
        ID_PRODUCTO = Integer.parseInt(txt_codprodcarrito.getText());
        CANTIDAD = Integer.parseInt(txt_cantidadcarrito.getText());
        PRECIO_UNITARIO = Float.parseFloat(txt_preciounitariocarrito.getText());
        SUBTOTAL = Float.parseFloat(txt_subtotaldelcarrito.getText());

        if (jrbutton_carritoefectivo.isSelected()) {
            METODO_PAGO = "Efectivo";
        } else if (jrbutton_carritotarjeta.isSelected()) {
            METODO_PAGO = "Tarjeta";
        } else {
            METODO_PAGO = "Billetera Digital";
        }

        NUMERO_TARJETA = txt_numerotarjeta.getText();
        Carrito_de_compras carrito = new Carrito_de_compras(ID, ID_CLIENTE, ID_PRODUCTO, CANTIDAD, PRECIO_UNITARIO, SUBTOTAL, METODO_PAGO, NUMERO_TARJETA);

        int r = modelCar.insertar(carrito);

        if (r == 1) {
            JOptionPane.showMessageDialog(this, "Se registro tu producto!");
            txt_idcarrito.setText("");
            txt_codclientecarrito.setText("");
            txt_codprodcarrito.setText("");
            txt_cantidadcarrito.setText("");
            txt_preciounitariocarrito.setText("");
            txt_subtotaldelcarrito.setText("");
            // Desseleccionar los botones de opción después de agregar al carrito
            jrbutton_carritoefectivo.setSelected(false);
            jrbutton_carritotarjeta.setSelected(false);
            jrbutton_billeteradigitalcarrito.setSelected(false);
        } else {

            JOptionPane.showMessageDialog(this, "Error al registrar!");
        }
        MostrarCarrito();

    }//GEN-LAST:event_button_agregaralcarritoActionPerformed

    private void txt_direccióndeliveryentreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_direccióndeliveryentreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_direccióndeliveryentreActionPerformed

    private void txt_idclientedeliveryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_idclientedeliveryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_idclientedeliveryActionPerformed

    private void txt_vendedordeliveryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_vendedordeliveryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_vendedordeliveryActionPerformed

    private void txt_nombreEmpdeliveryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nombreEmpdeliveryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nombreEmpdeliveryActionPerformed

    private void txt_DNI_compoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_DNI_compoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_DNI_compoActionPerformed

    private void txt_IGV_compoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_IGV_compoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_IGV_compoActionPerformed

    private void jButton_INSERTAR_COMPROBANTEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_INSERTAR_COMPROBANTEActionPerformed
        // TODO add your handling code here:
        int ID_BOLETA, ID_PEDIDO, ID_VENDEDOR;
        String NOMBRE, DNI, DIRECCION, F_EMICION, F_VENCCIMIENTO;
        float COSTO, IGV, TOTAL_PAGAR;

        ID_PEDIDO = Integer.parseInt(txt_ID_PEDIDO_compo.getText());
        ID_BOLETA = Integer.parseInt(txt_ID_BOLETA.getText());
        ID_VENDEDOR = Integer.parseInt(txt_ID_VENDEDOR_compo.getText());
        NOMBRE = txt_NOMBRE_CLIENTE.getText();
        DNI = txt_DNI_compo.getText();
        DIRECCION = txt_DIRECCION_compo.getText();
        F_EMICION = txt_F_EMICION_compo.getText();
        F_VENCCIMIENTO = txt_F_VENCIMIENTO_compo.getText();

        try {
            IGV = 0.18f;

            COSTO = Float.parseFloat(txt_COSTO_DELIVERY_cpmpo.getText());
            TOTAL_PAGAR = COSTO + (COSTO * IGV);

            txt_IGV_compo.setText(String.valueOf(IGV));
            txt_TOTAL_PAGAR_compo.setText(String.valueOf(TOTAL_PAGAR));

        } catch (NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Por favor, ingrese cantidades y precios válidos.");
            return;
        }

        Comprobante comp = new Comprobante(ID_BOLETA, NOMBRE, DNI, DIRECCION, F_EMICION, F_VENCCIMIENTO, ID_VENDEDOR, ID_PEDIDO, COSTO, IGV, TOTAL_PAGAR);

        int r = modelCompro.insertar(comp);

        if (r == 1) {
            JOptionPane.showMessageDialog(this, "Se registro el comprobante en la base de datos!");
            txt_ID_BOLETA.setText("");
            txt_ID_PEDIDO_compo.setText("");
            txt_ID_VENDEDOR_compo.setText("");
            txt_NOMBRE_CLIENTE.setText("");
            txt_DNI_compo.setText("");
            txt_DIRECCION_compo.setText("");
            txt_F_EMICION_compo.setText("");
            txt_F_VENCIMIENTO_compo.setText("");
            txt_COSTO_DELIVERY_cpmpo.setText("");
            txt_IGV_compo.setText("");
            txt_TOTAL_PAGAR_compo.setText("");

        } else {

            JOptionPane.showMessageDialog(this, "Error al registrar!");
        }
        Mostrar_Cmprobante();


    }//GEN-LAST:event_jButton_INSERTAR_COMPROBANTEActionPerformed

    private void Jbutton_CerrarConexionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Jbutton_CerrarConexionActionPerformed

        cerrarConexion();

        JOptionPane.showMessageDialog(this, "Sesión cerrada correctamente");

        this.setVisible(false);
        Verificacion_Usuario r2 = new Verificacion_Usuario();
        r2.setVisible(true);
    }//GEN-LAST:event_Jbutton_CerrarConexionActionPerformed

    public void mostrarAdmins() {
        ArrayList<Administracion> lista = modelAdm.lista();

        DefaultTableModel mdadm = new DefaultTableModel();

        mdadm.addColumn("ID");
        mdadm.addColumn("Nombres");
        mdadm.addColumn("Apellidos");
        mdadm.addColumn("DNI");
        mdadm.addColumn("Edad");
        mdadm.addColumn("Numero de contacto");
        mdadm.addColumn("Genero");
        mdadm.addColumn("Cargo");
        mdadm.addColumn("Contraseña");

        for (Administracion adm : lista) {
            mdadm.addRow(adm.getData());
        }
        Jtable_admins.setModel(mdadm);
    }

    public void mostrarProductos() {
        ArrayList<Producto> listaP = modelPro.lista();

        DefaultTableModel mdPro = new DefaultTableModel();

        mdPro.addColumn("ID del producto");
        mdPro.addColumn("Nombres");
        mdPro.addColumn("Descripcion");
        mdPro.addColumn("Stock");
        mdPro.addColumn("Fecha de vencimiento");
        mdPro.addColumn("Precio Unitario");
        mdPro.addColumn("Descuento");
        mdPro.addColumn("Id del proveedor");

        for (Producto adm : listaP) {
            mdPro.addRow(adm.getData());
        }
        Jtable_productos.setModel(mdPro);
    }

    public void mostrarProductos_Carrito() {
        ArrayList<Producto> listaP = modelPro.lista();

        DefaultTableModel mdPro = new DefaultTableModel();

        mdPro.addColumn("ID del producto");
        mdPro.addColumn("Nombres");
        mdPro.addColumn("Stock");
        mdPro.addColumn("Precio Unitario");

        for (Producto adm : listaP) {
            mdPro.addRow(adm.getDataCarrito());
        }
        jTable_productosvistacarrito.setModel(mdPro);
    }

    public void mostrarPedidos() {
        ArrayList<Pedidos> listaPed = modelPed.lista();

        DefaultTableModel mdPed = new DefaultTableModel();

        mdPed.addColumn("ID de pedido");
        mdPed.addColumn("Nombre");
        mdPed.addColumn("Descripcion");
        mdPed.addColumn("Fecha de pedido");
        mdPed.addColumn("Direccion");
        mdPed.addColumn("Referencia");
        mdPed.addColumn("Vendedor");
        mdPed.addColumn("Cliente");

        for (Pedidos ped : listaPed) {
            mdPed.addRow(ped.getData());
        }
        Jtable_pedidos.setModel(mdPed);
    }

    public void mostrarClientes() {
        ArrayList<Clientes> lista = modelCli.lista();

        DefaultTableModel mdcli = new DefaultTableModel();

        mdcli.addColumn("ID");
        mdcli.addColumn("Nombres");
        mdcli.addColumn("Apellidos");
        mdcli.addColumn("DNI");
        mdcli.addColumn("Edad");
        mdcli.addColumn("Numero de contacto");
        mdcli.addColumn("Genero");
        mdcli.addColumn("Tipo de Cliente");
        mdcli.addColumn("Contraseña");

        for (Clientes cli : lista) {
            mdcli.addRow(cli.getData());
        }
        JtableCli.setModel(mdcli);
    }

    public void mostrarProveedores() {
        ArrayList<Proveedores> lista = modelProv.lista();

        DefaultTableModel mdprov = new DefaultTableModel();

        mdprov.addColumn("ID");
        mdprov.addColumn("Nombres");
        mdprov.addColumn("Apellidos");
        mdprov.addColumn("DNI");
        mdprov.addColumn("Edad");
        mdprov.addColumn("Numero de contacto");
        mdprov.addColumn("Genero");
        mdprov.addColumn("Cargo de produccion");
        mdprov.addColumn("Contraseña");
        mdprov.addColumn("Razón Social");
        mdprov.addColumn("Lugar de origen");
        mdprov.addColumn("Calidad");

        for (Proveedores prov : lista) {
            mdprov.addRow(prov.getData());
        }
        jTableProveedor.setModel(mdprov);
    }

    public void Mostrar_Vendedores() {
        ArrayList<Vendedores> lista = modelVen.lista();

        DefaultTableModel mdven = new DefaultTableModel();

        mdven.addColumn("ID");
        mdven.addColumn("Nombres");
        mdven.addColumn("Apellidos");
        mdven.addColumn("DNI");
        mdven.addColumn("Edad");
        mdven.addColumn("Numero de contacto");
        mdven.addColumn("Genero");
        mdven.addColumn("Cargo");
        mdven.addColumn("Contraseña");
        mdven.addColumn("Pago mensual");

        for (Vendedores ven : lista) {
            mdven.addRow(ven.getData());
        }
        JtableVendedores.setModel(mdven);
    }

    public void MostrarDelivery() {
        ArrayList<Delivery> lista = modelDel.lista();

        DefaultTableModel mddel = new DefaultTableModel();

        mddel.addColumn("ID");
        mddel.addColumn("Fecha");
        mddel.addColumn("Nombre");
        mddel.addColumn("Direccion entrega");
        mddel.addColumn("Referencia");
        mddel.addColumn("Costo envio");
        mddel.addColumn("Telefono");
        mddel.addColumn("Vendedor");
        mddel.addColumn("Cliente");

        for (Delivery del : lista) {
            mddel.addRow(del.getData());
        }
        jTableDelivery.setModel(mddel);
    }

    public void MostrarCarrito() {
        ArrayList<Carrito_de_compras> lista = modelCar.lista();

        DefaultTableModel mdlcar = new DefaultTableModel();

        mdlcar.addColumn("Carrito N°");
        mdlcar.addColumn("Cliente");
        mdlcar.addColumn("Producto");
        mdlcar.addColumn("Cantidad");
        mdlcar.addColumn("Precio Unidad");
        mdlcar.addColumn("SubTotal");
        mdlcar.addColumn("Metodo de Pago");
        mdlcar.addColumn("Num de tarjeta");

        for (Carrito_de_compras Car : lista) {
            mdlcar.addRow(Car.getData());
        }
        jTable_CARRITO_COMPRAS.setModel(mdlcar);
    }

    public void Mostrar_Cmprobante() {
        ArrayList<Comprobante> lista = modelCompro.lista();

        DefaultTableModel mdlcomp = new DefaultTableModel();
        mdlcomp.addColumn("ID Boleta");
        mdlcomp.addColumn("Nombre");
        mdlcomp.addColumn("Dni");
        mdlcomp.addColumn("Direccion");
        mdlcomp.addColumn("Fecha de emision");
        mdlcomp.addColumn("Fecha de vencimient o");
        mdlcomp.addColumn("ID Vendedor");
        mdlcomp.addColumn("ID Pedido");
        mdlcomp.addColumn("Costo");
        mdlcomp.addColumn("IGV");
        mdlcomp.addColumn("Total a pagar");

        for (Comprobante com : lista) {
            mdlcomp.addRow(com.getData());
        }
        jTable_COMPROBANTE.setModel(mdlcomp);
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AGREGAR_DELIVERY;
    private javax.swing.JButton Button_EliminaClientes;
    private javax.swing.JButton Button_EliminarAdm;
    private javax.swing.JButton Button_EliminarProducto;
    private javax.swing.JButton Button_RegistrarProducto;
    private javax.swing.JLabel Clientes;
    private javax.swing.JLabel Clientes1;
    private javax.swing.JButton ELIMINAR_DELIVERY;
    private javax.swing.JLabel Empleados;
    private javax.swing.JButton Jbutton_CerrarConexion;
    private javax.swing.JTable JtableCli;
    private javax.swing.JTable JtableVendedores;
    private javax.swing.JTable Jtable_admins;
    private javax.swing.JTable Jtable_pedidos;
    private javax.swing.JTable Jtable_productos;
    private javax.swing.JTabbedPane Productos;
    private javax.swing.JTextField TxT_Direciconpedido;
    private javax.swing.JTextField TxT_codigopedido;
    private javax.swing.JTextField TxT_descripcionpedido;
    private javax.swing.JTextField TxT_idclientepedido;
    private javax.swing.JTextField TxT_ideliminar;
    private javax.swing.JTextField TxT_idvendedorpedido;
    private javax.swing.JTextField TxT_nombrepedido;
    private javax.swing.JButton button_agregaralcarrito;
    private javax.swing.JButton button_agregarpedido1;
    private javax.swing.JButton button_cancelarpedido;
    private javax.swing.JButton button_quitardelcarrito;
    private javax.swing.JButton jButton1_AGREGAR_CLIENTES;
    private javax.swing.JButton jButton_ADMINISTRADOR;
    private javax.swing.JButton jButton_CARRITO_COMPRAS;
    private javax.swing.JButton jButton_CLIENTES;
    private javax.swing.JButton jButton_COMPROBANTE_PAGO;
    private javax.swing.JButton jButton_DELIVERY;
    private javax.swing.JButton jButton_EMPRESA;
    private javax.swing.JButton jButton_INSERTAR_COMPROBANTE;
    private javax.swing.JButton jButton_PEDIDOS;
    private javax.swing.JButton jButton_PRODUCTOS_LACTEOS;
    private javax.swing.JButton jButton_PROVEEDOR;
    private javax.swing.JButton jButton_VENDEDOR;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTableDelivery;
    private javax.swing.JTable jTableProveedor;
    private javax.swing.JTable jTable_CARRITO_COMPRAS;
    private javax.swing.JTable jTable_COMPROBANTE;
    private javax.swing.JTable jTable_productosvistacarrito;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JButton jbutton_Agregarproveedor;
    private javax.swing.JButton jbutton_ContratarEmp;
    private javax.swing.JButton jbutton_despedirEmp;
    private javax.swing.JButton jbutton_eliminarproveedor;
    private javax.swing.JRadioButton jrbutton_billeteradigitalcarrito;
    private javax.swing.JRadioButton jrbutton_carritoefectivo;
    private javax.swing.JRadioButton jrbutton_carritotarjeta;
    private javax.swing.JRadioButton rbutton_ClienteFemenino;
    private javax.swing.JRadioButton rbutton_ClienteMasculino;
    private javax.swing.JRadioButton rbutton_ProveedorFemenina;
    private javax.swing.JRadioButton rbutton_ProveedorMasculino;
    private javax.swing.JRadioButton rbutton_VendedorFemenino;
    private javax.swing.JRadioButton rbutton_VendedorMasculino1;
    private javax.swing.JTextField txt_APELLIDOC;
    private javax.swing.JTextField txt_APELLIDOven;
    private javax.swing.JTextField txt_CARGOven;
    private javax.swing.JTextField txt_CLIENTE_CARGOC;
    private javax.swing.JTextField txt_CONTRASEÑAC;
    private javax.swing.JTextField txt_CONTRASEÑAven;
    private javax.swing.JTextField txt_COSTO_DELIVERY_cpmpo;
    private javax.swing.JTextField txt_DIRECCION_compo;
    private javax.swing.JTextField txt_DNIC;
    private javax.swing.JTextField txt_DNI_compo;
    private javax.swing.JTextField txt_DNIven;
    private javax.swing.JTextField txt_EDADC;
    private javax.swing.JTextField txt_EDADven;
    private javax.swing.JTextField txt_F_EMICION_compo;
    private javax.swing.JTextField txt_F_VENCIMIENTO_compo;
    private javax.swing.JTextField txt_IDC;
    private javax.swing.JTextField txt_ID_BOLETA;
    private javax.swing.JTextField txt_ID_PEDIDO_compo;
    private javax.swing.JTextField txt_ID_VENDEDOR_compo;
    private javax.swing.JTextField txt_IDven;
    private javax.swing.JTextField txt_IGV_compo;
    private javax.swing.JTextField txt_NOMBREC;
    private javax.swing.JTextField txt_NOMBRE_CLIENTE;
    private javax.swing.JTextField txt_NOMBREven;
    private javax.swing.JTextField txt_NUMEROTEven;
    private javax.swing.JTextField txt_NUMERO_TELEFONICOC;
    private javax.swing.JTextField txt_PAGOMENSUALven;
    private javax.swing.JTextField txt_TOTAL_PAGAR_compo;
    private javax.swing.JTextField txt_apellidoproveedor;
    private javax.swing.JTextField txt_calidadproveedor;
    private javax.swing.JTextField txt_cantidadcarrito;
    private javax.swing.JTextField txt_cargoproveedor;
    private javax.swing.JTextField txt_codclientecarrito;
    private javax.swing.JTextField txt_codprodcarrito;
    private javax.swing.JTextField txt_contraseñaproveedor;
    private javax.swing.JTextField txt_costodelivery;
    private javax.swing.JTextField txt_descripcion;
    private javax.swing.JTextField txt_descuento;
    private javax.swing.JTextField txt_direccióndeliveryentre;
    private javax.swing.JTextField txt_dniproveedor;
    private javax.swing.JTextField txt_edadproveedor;
    private javax.swing.JTextField txt_fechadelivery;
    private javax.swing.JTextField txt_fechadevencimiento;
    private javax.swing.JTextField txt_fechaped;
    private javax.swing.JTextField txt_idcarrito;
    private javax.swing.JTextField txt_idclientedelivery;
    private javax.swing.JTextField txt_iddelivery;
    private javax.swing.JTextField txt_idelproducto;
    private javax.swing.JTextField txt_idproveedor;
    private javax.swing.JTextField txt_idproveedorProd;
    private javax.swing.JTextField txt_lugardeorigenproveedor;
    private javax.swing.JTextField txt_nombreEmpdelivery;
    private javax.swing.JTextField txt_nombredelproducto;
    private javax.swing.JTextField txt_nombreproveedor;
    private javax.swing.JTextField txt_numerotarjeta;
    private javax.swing.JTextField txt_numerotelproveedor;
    private javax.swing.JTextField txt_preciounitariocarrito;
    private javax.swing.JTextField txt_preciounitarioproduc;
    private javax.swing.JTextField txt_razonsocialproveedor;
    private javax.swing.JTextField txt_referenciadelivery;
    private javax.swing.JTextField txt_referenciapedido;
    private javax.swing.JTextField txt_stock;
    private javax.swing.JLabel txt_subtotalcarrito;
    private javax.swing.JLabel txt_subtotalcarrito1;
    private javax.swing.JLabel txt_subtotalcarrito2;
    private javax.swing.JTextField txt_subtotaldelcarrito;
    private javax.swing.JTextField txt_telefonoCliente;
    private javax.swing.JTextField txt_vendedordelivery;
    // End of variables declaration//GEN-END:variables

}
