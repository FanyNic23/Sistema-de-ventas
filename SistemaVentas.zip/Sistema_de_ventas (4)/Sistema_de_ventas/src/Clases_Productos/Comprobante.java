
package Clases_Productos;


public class Comprobante {

    private int ID_COMPROBANTE;
    private String NOMBRE;
    private String DNI;
    private String DIRECCION;
    private String F_EMISION;
    private String F_VENCIMIENTO;
    private int ID_VENDEDOR;
    private int ID_PEDIDO;
    private float COSTO;
    private float IGV;
    private float TOTAL_PAGAR;

    public Comprobante() {
    }

    public Comprobante(int ID_COMPROBANTE) {
        this.ID_COMPROBANTE = ID_COMPROBANTE;
    }

    public Comprobante(int ID_COMPROBANTE, String NOMBRE, String DNI, String DIRECCION, String F_EMISION, String F_VENCIMIENTO, int ID_VENDEDOR, int ID_PEDIDO, float COSTO, float IGV, float TOTAL_PAGAR) {
        this.ID_COMPROBANTE = ID_COMPROBANTE;
        this.NOMBRE = NOMBRE;
        this.DNI = DNI;
        this.DIRECCION = DIRECCION;
        this.F_EMISION = F_EMISION;
        this.F_VENCIMIENTO = F_VENCIMIENTO;
        this.ID_VENDEDOR = ID_VENDEDOR;
        this.ID_PEDIDO = ID_PEDIDO;
        this.COSTO = COSTO;
        this.IGV = IGV;
        this.TOTAL_PAGAR = TOTAL_PAGAR;
    }

    public int getID_COMPROBANTE() {
        return ID_COMPROBANTE;
    }

    public void setID_COMPROBANTE(int ID_COMPROBANTE) {
        this.ID_COMPROBANTE = ID_COMPROBANTE;
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public void setNOMBRE(String NOMBRE) {
        this.NOMBRE = NOMBRE;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getDIRECCION() {
        return DIRECCION;
    }

    public void setDIRECCION(String DIRECCION) {
        this.DIRECCION = DIRECCION;
    }

    public String getF_EMISION() {
        return F_EMISION;
    }

    public void setF_EMISION(String F_EMISION) {
        this.F_EMISION = F_EMISION;
    }

    public String getF_VENCIMIENTO() {
        return F_VENCIMIENTO;
    }

    public void setF_VENCIMIENTO(String F_VENCIMIENTO) {
        this.F_VENCIMIENTO = F_VENCIMIENTO;
    }

    public int getID_VENDEDOR() {
        return ID_VENDEDOR;
    }

    public void setID_VENDEDOR(int ID_VENDEDOR) {
        this.ID_VENDEDOR = ID_VENDEDOR;
    }

    public int getID_PEDIDO() {
        return ID_PEDIDO;
    }

    public void setID_PEDIDO(int ID_PEDIDO) {
        this.ID_PEDIDO = ID_PEDIDO;
    }

    public float getCOSTO() {
        return COSTO;
    }

    public void setCOSTO(float COSTO) {
        this.COSTO = COSTO;
    }

    public float getIGV() {
        return IGV;
    }

    public void setIGV(float IGV) {
        this.IGV = IGV;
    }

    public float getTOTAL_PAGAR() {
        return TOTAL_PAGAR;
    }

    public void setTOTAL_PAGAR(float TOTAL_PAGAR) {
        this.TOTAL_PAGAR = TOTAL_PAGAR;
    }

    public String[] getData() {
        return new String[]{
            "" + ID_COMPROBANTE, NOMBRE, DNI, DIRECCION, F_EMISION, F_VENCIMIENTO, "" + ID_VENDEDOR, "" + ID_PEDIDO, "" + COSTO, "" + IGV, "" + TOTAL_PAGAR,};
    }
}
