/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Productos;

/**
 *
 * @author Genji DL
 */
public class Delivery {

    private int ID;
    private String FECHA;
    private String NOMBRE;
    private String DIRECION_ENTREGA;
    private String REFERENCIA;
    private float COSTO_ENVIO;
    private int TELEFONO;
    private int ID_VENDEDOR;
    private int ID_CLIENTE;

    public Delivery() {
    }

    public Delivery(int ID) {
        this.ID = ID;
    }

    public Delivery(int ID, String FECHA, String NOMBRE, String DIRECION_ENTREGA, String REFERENCIA, float COSTO_ENVIO, int TELEFONO, int ID_VENDEDOR, int ID_CLIENTE) {
        this.ID = ID;
        this.FECHA = FECHA;
        this.NOMBRE = NOMBRE;
        this.DIRECION_ENTREGA = DIRECION_ENTREGA;
        this.REFERENCIA = REFERENCIA;
        this.COSTO_ENVIO = COSTO_ENVIO;
        this.TELEFONO = TELEFONO;
        this.ID_VENDEDOR = ID_VENDEDOR;
        this.ID_CLIENTE = ID_CLIENTE;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFECHA() {
        return FECHA;
    }

    public void setFECHA(String FECHA) {
        this.FECHA = FECHA;
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public void setNOMBRE(String NOMBRE) {
        this.NOMBRE = NOMBRE;
    }

    public String getDIRECION_ENTREGA() {
        return DIRECION_ENTREGA;
    }

    public void setDIRECION_ENTREGA(String DIRECION_ENTREGA) {
        this.DIRECION_ENTREGA = DIRECION_ENTREGA;
    }

    public String getREFERENCIA() {
        return REFERENCIA;
    }

    public void setREFERENCIA(String REFERENCIA) {
        this.REFERENCIA = REFERENCIA;
    }

    public float getCOSTO_ENVIO() {
        return COSTO_ENVIO;
    }

    public void setCOSTO_ENVIO(float COSTO_ENVIO) {
        this.COSTO_ENVIO = COSTO_ENVIO;
    }

    public int getTELEFONO() {
        return TELEFONO;
    }

    public void setTELEFONO(int TELEFONO) {
        this.TELEFONO = TELEFONO;
    }

    public int getID_VENDEDOR() {
        return ID_VENDEDOR;
    }

    public void setID_VENDEDOR(int ID_VENDEDOR) {
        this.ID_VENDEDOR = ID_VENDEDOR;
    }

    public int getID_CLIENTE() {
        return ID_CLIENTE;
    }

    public void setID_CLIENTE(int ID_CLIENTE) {
        this.ID_CLIENTE = ID_CLIENTE;
    }

    public String[] getData() {
        return new String[]{"" + ID, FECHA, NOMBRE, DIRECION_ENTREGA, REFERENCIA, "" + COSTO_ENVIO, "" + TELEFONO, "" + ID_VENDEDOR,"" + ID_CLIENTE};
    }
}
