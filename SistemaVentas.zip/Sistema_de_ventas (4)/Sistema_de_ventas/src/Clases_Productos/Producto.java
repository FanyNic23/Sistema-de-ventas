/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Productos;

/**
 *
 * @author Genji DL
 */
public class Producto {

    private int ID;
    private String NOMBRE;
    private String DESCRIPCION;
    private int STOCK;
    private String FECHA_VENCIMIENTO;
    private float PRECIO_UNITARIO;
    private float DESCUENTO;
    private int ID_PROVEEDOR;

    public Producto() {
    }

    public Producto(int ID) {
        this.ID = ID;
    }

    public Producto(int ID, String NOMBRE, String DESCRIPCION, int STOCK, String FECHA_VENCIMIENTO, float PRECIO_UNITARIO, float DESCUENTO, int ID_PROVEEDOR) {
        this.ID = ID;
        this.NOMBRE = NOMBRE;
        this.DESCRIPCION = DESCRIPCION;
        this.STOCK = STOCK;
        this.FECHA_VENCIMIENTO = FECHA_VENCIMIENTO;
        this.PRECIO_UNITARIO = PRECIO_UNITARIO;
        this.DESCUENTO = DESCUENTO;
        this.ID_PROVEEDOR = ID_PROVEEDOR;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public void setNOMBRE(String NOMBRE) {
        this.NOMBRE = NOMBRE;
    }

    public String getDESCRIPCION() {
        return DESCRIPCION;
    }

    public void setDESCRIPCION(String DESCRIPCION) {
        this.DESCRIPCION = DESCRIPCION;
    }

    public int getSTOCK() {
        return STOCK;
    }

    public void setSTOCK(int STOCK) {
        this.STOCK = STOCK;
    }

    public String getFECHA_VENCIMIENTO() {
        return FECHA_VENCIMIENTO;
    }

    public void setFECHA_VENCIMIENTO(String FECHA_VENCIMIENTO) {
        this.FECHA_VENCIMIENTO = FECHA_VENCIMIENTO;
    }

    public float getPRECIO_UNITARIO() {
        return PRECIO_UNITARIO;
    }

    public void setPRECIO_UNITARIO(float PRECIO_UNITARIO) {
        this.PRECIO_UNITARIO = PRECIO_UNITARIO;
    }

    public float getDESCUENTO() {
        return DESCUENTO;
    }

    public void setDESCUENTO(float DESCUENTO) {
        this.DESCUENTO = DESCUENTO;
    }

    public int getID_PROVEEDOR() {
        return ID_PROVEEDOR;
    }

    public void setID_PROVEEDOR(int ID_PROVEEDOR) {
        this.ID_PROVEEDOR = ID_PROVEEDOR;
    }

    public String[] getData() {
        return new String[]{"" + ID, NOMBRE, DESCRIPCION, "" + STOCK, FECHA_VENCIMIENTO, "" + PRECIO_UNITARIO, "" + DESCUENTO, "" + ID_PROVEEDOR};
    }

    public String[] getDataCarrito() {
        return new String[]{"" + ID, NOMBRE, "" + STOCK, "" + PRECIO_UNITARIO};
    }

}
