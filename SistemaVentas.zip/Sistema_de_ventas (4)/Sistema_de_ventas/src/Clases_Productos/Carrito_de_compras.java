/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Productos;

/**
 *
 * @author Genji DL
 */
public class Carrito_de_compras {

    private int ID;
    private int ID_CLIENTE;
    private int ID_PRODUCTO;
    private int CANTIDAD;
    private float PRECIO_UNITARIO;
    private float SUBTOTAL;
    private String METODO_PAGO;
    private String NUMERO_TARJETA;

    public Carrito_de_compras() {
    }

    public Carrito_de_compras(int ID) {
        this.ID = ID;
    }

    public Carrito_de_compras(int ID, int ID_CLIENTE, int ID_PRODUCTO, int CANTIDAD, float PRECIO_UNITARIO, float SUBTOTAL, String METODO_PAGO, String NUMERO_TARJETA) {
        this.ID = ID;
        this.ID_CLIENTE = ID_CLIENTE;
        this.ID_PRODUCTO = ID_PRODUCTO;
        this.CANTIDAD = CANTIDAD;
        this.PRECIO_UNITARIO = PRECIO_UNITARIO;
        this.SUBTOTAL = SUBTOTAL;
        this.METODO_PAGO = METODO_PAGO;
        this.NUMERO_TARJETA = NUMERO_TARJETA;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getID_CLIENTE() {
        return ID_CLIENTE;
    }

    public void setID_CLIENTE(int ID_CLIENTE) {
        this.ID_CLIENTE = ID_CLIENTE;
    }

    public int getID_PRODUCTO() {
        return ID_PRODUCTO;
    }

    public void setID_PRODUCTO(int ID_PRODUCTO) {
        this.ID_PRODUCTO = ID_PRODUCTO;
    }

    public int getCANTIDAD() {
        return CANTIDAD;
    }

    public void setCANTIDAD(int CANTIDAD) {
        this.CANTIDAD = CANTIDAD;
    }

    public float getPRECIO_UNITARIO() {
        return PRECIO_UNITARIO;
    }

    public void setPRECIO_UNITARIO(float PRECIO_UNITARIO) {
        this.PRECIO_UNITARIO = PRECIO_UNITARIO;
    }

    public float getSUBTOTAL() {
        return SUBTOTAL;
    }

    public void setSUBTOTAL(float SUBTOTAL) {
        this.SUBTOTAL = SUBTOTAL;
    }

    public String getMETODO_PAGO() {
        return METODO_PAGO;
    }

    public void setMETODO_PAGO(String METODO_PAGO) {
        this.METODO_PAGO = METODO_PAGO;
    }

    public String getNUMERO_TARJETA() {
        return NUMERO_TARJETA;
    }

    public void setNUMERO_TARJETA(String NUMERO_TARJETA) {
        this.NUMERO_TARJETA = NUMERO_TARJETA;
    }

    public String[] getData() {
        return new String[]{"" + ID, "" + ID_CLIENTE, "" + ID_PRODUCTO, "" + CANTIDAD, "" + PRECIO_UNITARIO, "" + SUBTOTAL, "" + METODO_PAGO, "" + NUMERO_TARJETA};
    }
}
