/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Productos;

/**
 *
 * @author Genji DL
 */
public class Pedidos extends Producto {

    private int VENDEDOR_ID;
    private int CLIENTE_ID;
    private String DIRECCION;
    private String REFERENCIA;

    public Pedidos() {
    }

    public Pedidos(int ID) {
        super(ID);
    }

    public Pedidos(int VENDEDOR_ID, int CLIENTE_ID, String DIRECCION, String REFERENCIA, int ID, String NOMBRE, String DESCRIPCION, int STOCK, String FECHA_VENCIMIENTO, float PRECIO_UNITARIO, float DESCUENTO, int ID_PROVEEDOR) {
        super(ID, NOMBRE, DESCRIPCION, STOCK, FECHA_VENCIMIENTO, PRECIO_UNITARIO, DESCUENTO, ID_PROVEEDOR);
        this.VENDEDOR_ID = VENDEDOR_ID;
        this.CLIENTE_ID = CLIENTE_ID;
        this.DIRECCION = DIRECCION;
        this.REFERENCIA = REFERENCIA;
    }

    public int getVENDEDOR_ID() {
        return VENDEDOR_ID;
    }

    public void setVENDEDOR_ID(int VENDEDOR_ID) {
        this.VENDEDOR_ID = VENDEDOR_ID;
    }

    public int getCLIENTE_ID() {
        return CLIENTE_ID;
    }

    public void setCLIENTE_ID(int CLIENTE_ID) {
        this.CLIENTE_ID = CLIENTE_ID;
    }

    public String getDIRECCION() {
        return DIRECCION;
    }

    public void setDIRECCION(String DIRECCION) {
        this.DIRECCION = DIRECCION;
    }

    public String getREFERENCIA() {
        return REFERENCIA;
    }

    public void setREFERENCIA(String REFERENCIA) {
        this.REFERENCIA = REFERENCIA;
    }

    public String[] getData() {
        String[] productoData = super.getData();

        String[] pedidoData = new String[]{
            "" + getID(),
            productoData[1], // NOMBRE
            productoData[2], // DESCRIPCION
            productoData[4], // FECHA DE PEDIDO
            "" + DIRECCION,
            "" + REFERENCIA,
            "" + VENDEDOR_ID,
            "" + CLIENTE_ID
        };

        String[] combinedData = new String[pedidoData.length];
        System.arraycopy(pedidoData, 0, combinedData, 0, pedidoData.length);

        return combinedData;
    }
}
