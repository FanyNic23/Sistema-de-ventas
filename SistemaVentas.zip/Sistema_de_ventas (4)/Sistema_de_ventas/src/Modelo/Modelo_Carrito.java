/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Clases_Productos.Carrito_de_compras;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Genji DL
 */
public class Modelo_Carrito extends Conexion<Carrito_de_compras> {

    private Connection con;
    private PreparedStatement sp;
    private ResultSet result;

    public Modelo_Carrito() {
        super();
        this.con = getCn();
    }

    @Override
    public int insertar(Carrito_de_compras objeto) {
        try {
            String sql = "INSERT INTO `carrito_compras`(`CCP_ID`, `CLIENTE_ID`, `PROD_ID`, `CCP_CANTIDAD`, `CCP_PRECIOUNITARIO`, `CCP_SUBTOTAL`, `CCP_METODO_PAGO`, `CCP_NUMTARJETA`) VALUES (?,?,?,?,?,?,?,?)";
            sp = con.prepareStatement(sql);
            sp.setInt(1, objeto.getID());
            sp.setInt(2, objeto.getID_CLIENTE());
            sp.setInt(3, objeto.getID_PRODUCTO());
            sp.setInt(4, objeto.getCANTIDAD());
            sp.setFloat(5, objeto.getPRECIO_UNITARIO());
            sp.setFloat(6, objeto.getSUBTOTAL());
            sp.setString(7, objeto.getMETODO_PAGO());
            sp.setString(8, objeto.getNUMERO_TARJETA());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            return 0;
        }

    }

    @Override
    public ArrayList<Carrito_de_compras> lista() {
        ArrayList<Carrito_de_compras> lista = new ArrayList<>();
        String sql = "SELECT `CCP_ID`, `CLIENTE_ID`, `PROD_ID`, `CCP_CANTIDAD`, `CCP_PRECIOUNITARIO`, `CCP_SUBTOTAL`, `CCP_METODO_PAGO`, `CCP_NUMTARJETA` FROM `carrito_compras`";

        try {
            Statement st = con.createStatement();

            result = st.executeQuery(sql);

            while (result.next()) {
                Carrito_de_compras cdc = new Carrito_de_compras();
                cdc.setID(result.getInt(1));
                cdc.setID_CLIENTE(result.getInt(2));

                cdc.setID_PRODUCTO(result.getInt(3));
                cdc.setCANTIDAD(result.getInt(4));
                cdc.setPRECIO_UNITARIO(result.getFloat(5));
                cdc.setSUBTOTAL(result.getFloat(6));
                cdc.setMETODO_PAGO(result.getString(7));
                cdc.setNUMERO_TARJETA(result.getString(8));
                lista.add(cdc);
            }

        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return lista;
    }

    @Override
    public int eliminar(Carrito_de_compras cdc) {
        String sql = "DELETE FROM `carrito_compras` WHERE `CCP_ID` = ?";

        try (PreparedStatement sp = con.prepareStatement(sql)) {
            sp.setInt(1, cdc.getID());

            int res = sp.executeUpdate();

            return res;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el carrito de compras con ID " + cdc.getID() + ": " + e.getMessage());
            return 0;
        }
    }

}
