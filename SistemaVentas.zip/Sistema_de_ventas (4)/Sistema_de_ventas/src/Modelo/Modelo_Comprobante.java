
package Modelo;

import Clases_Productos.Comprobante;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.ArrayList;

/**
 *
 * @author Genji DL
 */
public class Modelo_Comprobante extends Conexion<Comprobante> {

    private Connection con;
    private PreparedStatement sp;
    private ResultSet result;

    public Modelo_Comprobante() {
        super();
        this.con = getCn();
    }

    @Override
    public int insertar(Comprobante objeto) {
        try {
            String sql = "INSERT INTO `comprobante`(`ID_COMPROBANTE`, `NOMBRE`, `DNI`, `DIRECCION`, `F_EMISION`, `F_VENCIMIENTO`, `ID_VENDEDOR`, `ID_PEDIDO`, `COSTO`, `IGV`, `TOTAL_PAGAR`) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            sp = con.prepareStatement(sql);
            sp.setInt(1, objeto.getID_COMPROBANTE());
            sp.setString(2, objeto.getNOMBRE());
            sp.setString(3, objeto.getDNI());
            sp.setString(4, objeto.getDIRECCION());
            sp.setString(5, objeto.getF_EMISION());
            sp.setString(6, objeto.getF_VENCIMIENTO());
            sp.setInt(7, objeto.getID_VENDEDOR());
            sp.setInt(8, objeto.getID_PEDIDO());
            sp.setDouble(9, objeto.getCOSTO());
            sp.setDouble(10, objeto.getIGV());
            sp.setDouble(11, objeto.getTOTAL_PAGAR());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            return 0;
        }
    }

    @Override
    public ArrayList<Comprobante> lista() {
        ArrayList<Comprobante> lista = new ArrayList<>();

        String sql = "SELECT `ID_COMPROBANTE`, `NOMBRE`, `DNI`, `DIRECCION`, `F_EMISION`, `F_VENCIMIENTO`, `ID_VENDEDOR`, `ID_PEDIDO`, `COSTO`, `IGV`, `TOTAL_PAGAR` FROM `comprobante`";

        try {
            Statement st = con.createStatement();

            result = st.executeQuery(sql);

            while (result.next()) {
                Comprobante comprobante = new Comprobante();
                comprobante.setID_COMPROBANTE(result.getInt(1));
                comprobante.setNOMBRE(result.getString(2));
                comprobante.setDNI(result.getString(3));
                comprobante.setDIRECCION(result.getString(4));
                comprobante.setF_EMISION(result.getString(5));
                comprobante.setF_VENCIMIENTO(result.getString(6));
                comprobante.setID_VENDEDOR(result.getInt(7));
                comprobante.setID_PEDIDO(result.getInt(8));
                comprobante.setCOSTO(result.getFloat(9));
                comprobante.setIGV(result.getFloat(10));
                comprobante.setTOTAL_PAGAR(result.getFloat(11));

                lista.add(comprobante);
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return lista;
    }

    @Override
    public int eliminar(Comprobante comprobante) {
        try {
            String sql = "DELETE FROM `comprobante` WHERE `ID_COMPROBANTE` = ?";
            sp = con.prepareStatement(sql);

            sp.setInt(1, comprobante.getID_COMPROBANTE());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }

}
