/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Clases_Personas.Proveedores;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Genji DL
 */
public class Modelo_Proveedores extends Conexion<Proveedores> {

    private Connection con;
    private PreparedStatement sp;
    private ResultSet result;

    public Modelo_Proveedores() {
        super();
        this.con = getCn();
    }

    @Override
    public int insertar(Proveedores objeto) {
        try {
            String sql = "INSERT INTO `proveedores`(`PRV_ID`, `PRV_NOMBRE`, `PRV_APELLIDO`, `PRV_DNI`, `PRV_EDAD`, `PRV_NUMEROTELEFONICO`, `PRV_GENERO`, `PRV_CARGO`, `PRV_CONTRASENIA`,`PRV_RAZONSOCIAL`,`PRV_LUGARDEORIGEN`,`PRV_CALIDAD`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
            sp = con.prepareStatement(sql);
            sp.setInt(1, objeto.getID());
            sp.setString(2, objeto.getNOMBRES());
            sp.setString(3, objeto.getAPELLIDOS());
            sp.setString(4, objeto.getDNI());
            sp.setString(5, objeto.getEDAD());
            sp.setInt(6, objeto.getNUMERO_TELEFONO());
            sp.setString(7, objeto.getGENERO());
            sp.setString(8, objeto.getCARGO());
            sp.setString(9, objeto.getCONTRASENIA());
            sp.setString(10, objeto.getRAZON_SOCIAL());
            sp.setString(11, objeto.getLUGAR_DE_ORIGEN());
            sp.setString(12, objeto.getCALIDAD());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            return 0;
        }
    }

    @Override
    public ArrayList<Proveedores> lista() {
        ArrayList<Proveedores> lista = new ArrayList<>();

        String sql = "SELECT `PRV_ID`, `PRV_NOMBRE`, `PRV_APELLIDO`, `PRV_DNI`, `PRV_EDAD`, `PRV_NUMEROTELEFONICO`, `PRV_GENERO`, `PRV_CARGO`, `PRV_CONTRASENIA`,`PRV_RAZONSOCIAL`,`PRV_LUGARDEORIGEN`,`PRV_CALIDAD`  FROM `proveedores`";

        try {
            Statement st = con.createStatement();

            result = st.executeQuery(sql);

            while (result.next()) {
                Proveedores prov = new Proveedores();
                prov.setID(result.getInt(1));
                prov.setNOMBRES(result.getString(2));
                prov.setAPELLIDOS(result.getString(3));
                prov.setDNI(result.getString(4));
                prov.setEDAD(result.getString(5));
                prov.setNUMERO_TELEFONO(result.getInt(6));
                prov.setGENERO(result.getString(7));
                prov.setCARGO(result.getString(8));
                prov.setCONTRASENIA(result.getString(9));
                prov.setRAZON_SOCIAL(result.getString(10));
                prov.setLUGAR_DE_ORIGEN(result.getString(11));
                prov.setCALIDAD(result.getString(12));

                lista.add(prov);
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return lista;
    }

    @Override
    public int eliminar(Proveedores prov) {
        try {
            String sql = "DELETE FROM `proveedores` WHERE `PRV_ID` = ?";
            sp = con.prepareStatement(sql);

            sp.setInt(1, prov.getID());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
}
