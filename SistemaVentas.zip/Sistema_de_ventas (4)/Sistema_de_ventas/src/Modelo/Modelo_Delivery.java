/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Clases_Productos.Delivery;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Genji DL
 */
public class Modelo_Delivery extends Conexion<Delivery> {

    private Connection con;
    private PreparedStatement sp;
    private ResultSet result;

    public Modelo_Delivery() {
        super();
        this.con = getCn();
    }

    @Override
    public int insertar(Delivery objeto) {
        try {
            String sql = "INSERT INTO `delivery`(`DEL_ID`, `DEL_FECHA_DELIVERY`, `DEL_NOMBRE`, `DEL_DIRECCIONDEENTREGA`, `DEL_REFERENCIA`, `DEL_COSTOENV`, `DEL_TELEFONO`, `VEN_ID`, `CLI_ID`) VALUES (?,?,?,?,?,?,?,?,?)";
            sp = con.prepareStatement(sql);
            sp.setInt(1, objeto.getID());
            sp.setString(2, objeto.getFECHA());
            sp.setString(3, objeto.getNOMBRE());
            sp.setString(4, objeto.getDIRECION_ENTREGA());
            sp.setString(5, objeto.getREFERENCIA());
            sp.setFloat(6, objeto.getCOSTO_ENVIO());
            sp.setInt(7, objeto.getTELEFONO());
            sp.setInt(8, objeto.getID_VENDEDOR());
            sp.setInt(9, objeto.getID_CLIENTE());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }

    @Override
    public ArrayList<Delivery> lista() {
        ArrayList<Delivery> lista = new ArrayList<>();

        String sql = "SELECT `DEL_ID`, `DEL_FECHA_DELIVERY`, `DEL_NOMBRE`, `DEL_DIRECCIONDEENTREGA`, `DEL_REFERENCIA`, `DEL_COSTOENV`, `DEL_TELEFONO`, `VEN_ID`, `CLI_ID` FROM `delivery`";

        try {
            Statement st = con.createStatement();
            result = st.executeQuery(sql);

            while (result.next()) {
                Delivery delivery = new Delivery();
                delivery.setID(result.getInt(1));
                delivery.setFECHA(result.getString(2));
                delivery.setNOMBRE(result.getString(3));
                delivery.setDIRECION_ENTREGA(result.getString(4));
                delivery.setREFERENCIA(result.getString(5));
                delivery.setCOSTO_ENVIO(result.getFloat(6));
                delivery.setTELEFONO(result.getInt(7));
                delivery.setID_VENDEDOR(result.getInt(8));

                lista.add(delivery);
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }

        return lista;
    }

    @Override
    public int eliminar(Delivery obj) {
        try {
            String sql = "DELETE FROM `delivery` WHERE `DEL_ID`=?";
            sp = con.prepareStatement(sql);
            sp.setInt(1, obj.getID());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
}
