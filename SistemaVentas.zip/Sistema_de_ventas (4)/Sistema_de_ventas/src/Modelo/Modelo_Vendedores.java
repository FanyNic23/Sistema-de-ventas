/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Clases_Personas.Vendedores;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Genji DL
 */
public class Modelo_Vendedores extends Conexion<Vendedores> {

    private Connection con;
    private PreparedStatement sp;
    private ResultSet result;

    public Modelo_Vendedores() {
        super();
        this.con = getCn();
    }

    @Override
    public int insertar(Vendedores objeto) {
        try {
            String sql = "INSERT INTO `vendedores`(`VEN_ID`, `VEN_NOMBRE`, `VEN_APELLIDO`, `VEN_DNI`, `VEN_EDAD`, `VEN_NUMEROTELEFONICO`, `VEN_GENERO`, `VEN_CARGO`, `VEN_CONTRASENIA`, `VEN_PAGOMENSUAL`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            sp = con.prepareStatement(sql);
            sp.setInt(1, objeto.getID());
            sp.setString(2, objeto.getNOMBRES());
            sp.setString(3, objeto.getAPELLIDOS());
            sp.setString(4, objeto.getDNI());
            sp.setString(5, objeto.getEDAD());
            sp.setInt(6, objeto.getNUMERO_TELEFONO());
            sp.setString(7, objeto.getGENERO());
            sp.setString(8, objeto.getCARGO());
            sp.setString(9, objeto.getCONTRASENIA());
            sp.setFloat(10, objeto.getPAGO_MENSUAL());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }

    @Override
    public ArrayList<Vendedores> lista() {
        ArrayList<Vendedores> lista = new ArrayList<>();

        String sql = "SELECT `VEN_ID`, `VEN_NOMBRE`, `VEN_APELLIDO`, `VEN_DNI`, `VEN_EDAD`, `VEN_NUMEROTELEFONICO`, `VEN_GENERO`, `VEN_CARGO`, `VEN_CONTRASENIA`, `VEN_PAGOMENSUAL` FROM `vendedores`";

        try {
            Statement st = con.createStatement();
            result = st.executeQuery(sql);

            while (result.next()) {
                Vendedores vendedor = new Vendedores();
                vendedor.setID(result.getInt(1));
                vendedor.setNOMBRES(result.getString(2));
                vendedor.setAPELLIDOS(result.getString(3));
                vendedor.setDNI(result.getString(4));
                vendedor.setEDAD(result.getString(5));
                vendedor.setNUMERO_TELEFONO(result.getInt(6));
                vendedor.setGENERO(result.getString(7));
                vendedor.setCARGO(result.getString(8));
                vendedor.setCONTRASENIA(result.getString(9));
                vendedor.setPAGO_MENSUAL(result.getFloat(10));

                lista.add(vendedor);
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return lista;
    }

    @Override
    public int eliminar(Vendedores obj) {
        try {
            String sql = "DELETE FROM `vendedores` WHERE `VEN_ID`=?";
            sp = con.prepareStatement(sql);
            sp.setInt(1, obj.getID());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
}
