/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Clases_Productos.Delivery;
import Clases_Productos.Pedidos;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Genji DL
 */
public class Modelo_Pedidos extends Conexion<Pedidos> {

    private Connection con;
    private PreparedStatement sp;
    private ResultSet result;

    public Modelo_Pedidos() {
        super();
        this.con = getCn();
    }

    @Override
    public int insertar(Pedidos objeto) {
        try {
            String sql = "INSERT INTO `pedidos`(`PED_ID`, `PED_NOMBRE`, `PED_DESCRIPCION`, `PED_FECHA_PEDIDO`, `PED_DIRECCIONDEENTREGA`, `PED_REFERENCIA`, `VEN_ID`, `CLI_ID`) VALUES (?,?,?,?,?,?,?,?)";
            sp = con.prepareStatement(sql);
            sp.setInt(1, objeto.getID());
            sp.setString(2, objeto.getNOMBRE());
            sp.setString(3, objeto.getDESCRIPCION());
            sp.setString(4, objeto.getFECHA_VENCIMIENTO());
            sp.setString(5, objeto.getDIRECCION());
            sp.setString(6, objeto.getREFERENCIA());
            sp.setInt(7, objeto.getVENDEDOR_ID());
            sp.setInt(8, objeto.getCLIENTE_ID());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error al insertar pedido: " + e.getMessage());
            return 0;
        }
    }

    @Override
    public ArrayList<Pedidos> lista() {
        ArrayList<Pedidos> lista = new ArrayList<>();

        String sql = "SELECT `PED_ID`, `PED_NOMBRE`, `PED_DESCRIPCION`, `PED_FECHA_PEDIDO`, `PED_DIRECCIONDEENTREGA`, `PED_REFERENCIA`, `VEN_ID`, `CLI_ID` FROM `pedidos`";

        try {
            try (Statement st = con.createStatement()) {
                result = st.executeQuery(sql);

                while (result.next()) {
                    Pedidos pedidos = new Pedidos();
                    pedidos.setID(result.getInt(1));
                    pedidos.setNOMBRE(result.getString(2));
                    pedidos.setDESCRIPCION(result.getString(3));
                    pedidos.setFECHA_VENCIMIENTO(result.getString(4)); // fecha de pedido
                    pedidos.setDIRECCION(result.getString(5));
                    pedidos.setREFERENCIA(result.getString(6));
                    pedidos.setVENDEDOR_ID(result.getInt(7));
                    pedidos.setCLIENTE_ID(result.getInt(8));
                    lista.add(pedidos);
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener la lista de pedidos: " + ex.getMessage());
        }
        return lista;
    }

    @Override
    public int eliminar(Pedidos obj) {
        try {
            String sql = "DELETE FROM `pedidos` WHERE `PED_ID`=?";
            sp = con.prepareStatement(sql);
            sp.setInt(1, obj.getID());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }

}
