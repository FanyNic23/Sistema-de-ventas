/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Clases_Personas.Administracion;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Genji DL
 */
public class Modelo_Administracion extends Conexion<Administracion> {

    private Connection con;
    private PreparedStatement sp;
    private ResultSet result;

    public Modelo_Administracion() {
        super();
        this.con = getCn();
    }

    @Override
    public int insertar(Administracion objeto) {
        try {
            String sql = "INSERT INTO `administrativo`(`ADM_ID`, `ADM_NOMBRE`, `ADM_APELLIDO`, `ADM_DNI`, `ADM_EDAD`, `ADM_NUMEROTELEFONICO`, `ADM_GENERO`, `ADM_CARGO`, `ADM_CONTRASEÑA`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            sp = con.prepareStatement(sql);
            sp.setInt(1, objeto.getID());
            sp.setString(2, objeto.getNOMBRES());
            sp.setString(3, objeto.getAPELLIDOS());
            sp.setString(4, objeto.getDNI());
            sp.setString(5, objeto.getEDAD());
            sp.setInt(6, objeto.getNUMERO_TELEFONO());
            sp.setString(7, objeto.getGENERO());
            sp.setString(8, objeto.getCARGO());
            sp.setString(9, objeto.getCONTRASENIA());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            return 0;
        }
    }

    @Override
    public ArrayList<Administracion> lista() {
        ArrayList<Administracion> lista = new ArrayList<>();

        String sql = "SELECT `ADM_ID`, `ADM_NOMBRE`, `ADM_APELLIDO`, `ADM_DNI`, `ADM_EDAD`, `ADM_NUMEROTELEFONICO`, `ADM_GENERO`, `ADM_CARGO`, `ADM_CONTRASEÑA` FROM `administrativo`";

        try {
            Statement st = con.createStatement();

            result = st.executeQuery(sql);

            while (result.next()) {
                Administracion admin = new Administracion();
                admin.setID(result.getInt(1));
                admin.setNOMBRES(result.getString(2));
                admin.setAPELLIDOS(result.getString(3));
                admin.setDNI(result.getString(4));
                admin.setEDAD(result.getString(5));
                admin.setNUMERO_TELEFONO(result.getInt(6));
                admin.setGENERO(result.getString(7));
                admin.setCARGO(result.getString(8));
                admin.setCONTRASENIA(result.getString(9));

                lista.add(admin);
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return lista;
    }

    @Override
    public int eliminar(Administracion admin) {
        try {
            String sql = "DELETE FROM `administrativo` WHERE `ADM_ID` = ?";
            sp = con.prepareStatement(sql);

            sp.setInt(1, admin.getID());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }

}
