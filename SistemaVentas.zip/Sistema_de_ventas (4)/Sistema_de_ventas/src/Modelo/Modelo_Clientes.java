/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Clases_Personas.Clientes;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Genji DL
 */
public class Modelo_Clientes extends Conexion<Clientes> {

    private Connection con;
    private PreparedStatement sp;
    private ResultSet result;

    public Modelo_Clientes() {
        super();
        this.con = getCn();
    }

    @Override
    public int insertar(Clientes objeto) {
        try {
            String sql = "INSERT INTO `clientes`(`CLI_ID`, `CLI_NOMBRE`, `CLI_APELLIDO`, `CLI_DNI`, `CLI_EDAD`, `CLI_NUMEROTELEFONICO`, `CLI_GENERO`, `CLI_CARGO`, `CLI_CONTRASENIA`) VALUES (?,?,?,?,?,?,?,?,?)";
            sp = con.prepareStatement(sql);
            sp.setInt(1, objeto.getID());
            sp.setString(2, objeto.getNOMBRES());
            sp.setString(3, objeto.getAPELLIDOS());
            sp.setString(4, objeto.getDNI());
            sp.setString(5, objeto.getEDAD());
            sp.setInt(6, objeto.getNUMERO_TELEFONO());
            sp.setString(7, objeto.getGENERO());
            sp.setString(8, objeto.getCARGO());
            sp.setString(9, objeto.getCONTRASENIA());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            return 0;
        }
    }

    @Override
    public ArrayList<Clientes> lista() {
        ArrayList<Clientes> lista = new ArrayList<>();

        String sql = "SELECT `CLI_ID`, `CLI_NOMBRE`, `CLI_APELLIDO`, `CLI_DNI`, `CLI_EDAD`, `CLI_NUMEROTELEFONICO`, `CLI_GENERO`, `CLI_CARGO`, `CLI_CONTRASENIA` FROM `clientes`";

        try {
            Statement st = con.createStatement();

            result = st.executeQuery(sql);

            while (result.next()) {
                Clientes cli = new Clientes();
                cli.setID(result.getInt(1));
                cli.setNOMBRES(result.getString(2));
                cli.setAPELLIDOS(result.getString(3));
                cli.setDNI(result.getString(4));
                cli.setEDAD(result.getString(5));
                cli.setNUMERO_TELEFONO(result.getInt(6));
                cli.setGENERO(result.getString(7));
                cli.setCARGO(result.getString(8));
                cli.setCONTRASENIA(result.getString(9));

                lista.add(cli);
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return lista;
    }

    @Override
    public int eliminar(Clientes cli) {
        try {
            String sql = "DELETE FROM `clientes` WHERE `CLI_ID` = ?";
            sp = con.prepareStatement(sql);

            sp.setInt(1, cli.getID());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
}
