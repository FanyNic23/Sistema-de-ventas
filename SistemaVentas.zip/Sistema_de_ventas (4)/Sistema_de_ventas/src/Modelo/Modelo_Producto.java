/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Clases_Productos.Producto;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Genji DL
 */
public class Modelo_Producto extends Conexion<Producto> {

    private Connection con;
    private PreparedStatement sp;
    private ResultSet result;

    public Modelo_Producto() {
        super();
        this.con = getCn();
    }

    @Override
    public int insertar(Producto objeto) {
        try {
            String sql = "INSERT INTO `productos`(`PROD_ID`, `PROD_NOMBRE`, `PROD_DESCRIPCION`, `PROD_STOCK`, `PROD_FECHA_DE_VENCIMIENTO`, `PROD_PRECIOUNITARIO`, `PROD_DESCUENTO`, `PRV_ID`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            sp = con.prepareStatement(sql);
            sp.setInt(1, objeto.getID());
            sp.setString(2, objeto.getNOMBRE());
            sp.setString(3, objeto.getDESCRIPCION());
            sp.setInt(4, objeto.getSTOCK());
            sp.setString(5, objeto.getFECHA_VENCIMIENTO());
            sp.setFloat(6, objeto.getPRECIO_UNITARIO());
            sp.setFloat(7, objeto.getDESCUENTO());
            sp.setInt(8, objeto.getID_PROVEEDOR());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            return 0;
        }
    }

    @Override
    public ArrayList<Producto> lista() {
        ArrayList<Producto> lista = new ArrayList<>();

        String sql = "SELECT `PROD_ID`, `PROD_NOMBRE`, `PROD_DESCRIPCION`, `PROD_STOCK`, `PROD_FECHA_DE_VENCIMIENTO`, `PROD_PRECIOUNITARIO`, `PROD_DESCUENTO`, `PRV_ID` FROM `productos`";

        try {
            Statement st = con.createStatement();
            result = st.executeQuery(sql);

            while (result.next()) {
                Producto producto = new Producto();
                producto.setID(result.getInt(1));
                producto.setNOMBRE(result.getString(2));
                producto.setDESCRIPCION(result.getString(3));
                producto.setSTOCK(result.getInt(4));
                producto.setFECHA_VENCIMIENTO(result.getString(5));
                producto.setPRECIO_UNITARIO(result.getFloat(6));
                producto.setDESCUENTO(result.getFloat(7));
                producto.setID_PROVEEDOR(result.getInt(8));

                lista.add(producto);
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return lista;
    }

    @Override
    public int eliminar(Producto obj) {
        try {
            String sql = "DELETE FROM `productos` WHERE `PROD_ID`=?";
            sp = con.prepareStatement(sql);
            sp.setInt(1, obj.getID());

            int res = sp.executeUpdate();

            sp.close();

            return res;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
}
