/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Personas;

/**
 *
 * @author Genji DL
 */
public class Proveedores extends Administracion {

    private String RAZON_SOCIAL;
    private String LUGAR_DE_ORIGEN;
    private String CALIDAD;

    public Proveedores() {
    }

    public Proveedores(int ID) {
        super(ID);
    }

    public Proveedores(String RAZON_SOCIAL, String LUGAR_DE_ORIGEN, String CALIDAD, int ID, String NOMBRES, String APELLIDOS, String DNI, String EDAD, int NUMERO_TELEFONO, String GENERO, String CARGO, String CONTRASENIA) {
        super(ID, NOMBRES, APELLIDOS, DNI, EDAD, NUMERO_TELEFONO, GENERO, CARGO, CONTRASENIA);
        this.RAZON_SOCIAL = RAZON_SOCIAL;
        this.LUGAR_DE_ORIGEN = LUGAR_DE_ORIGEN;
        this.CALIDAD = CALIDAD;
    }

    public String getRAZON_SOCIAL() {
        return RAZON_SOCIAL;
    }

    public void setRAZON_SOCIAL(String RAZON_SOCIAL) {
        this.RAZON_SOCIAL = RAZON_SOCIAL;
    }

    public String getLUGAR_DE_ORIGEN() {
        return LUGAR_DE_ORIGEN;
    }

    public void setLUGAR_DE_ORIGEN(String LUGAR_DE_ORIGEN) {
        this.LUGAR_DE_ORIGEN = LUGAR_DE_ORIGEN;
    }

    public String getCALIDAD() {
        return CALIDAD;
    }

    public void setCALIDAD(String CALIDAD) {
        this.CALIDAD = CALIDAD;
    }

    public String[] getData() {
        String[] adminData = super.getData();
        String[] proveedorData = new String[]{"" + RAZON_SOCIAL, "" + LUGAR_DE_ORIGEN, "" + CALIDAD};
        String[] combinedData = new String[adminData.length + proveedorData.length];
        System.arraycopy(adminData, 0, combinedData, 0, adminData.length);
        System.arraycopy(proveedorData, 0, combinedData, adminData.length, proveedorData.length);

        return combinedData;
    }

}
