/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Personas;

/**
 *
 * @author Genji DL
 */
public class Administracion {

    private int ID;
    private String NOMBRES;
    private String APELLIDOS;
    private String DNI;
    private String EDAD;
    private int NUMERO_TELEFONO;
    private String GENERO;
    private String CARGO;
    private String CONTRASENIA;

    public Administracion() {
    }

    public Administracion(int ID) {
        this.ID = ID;
    }

    public Administracion(int ID, String CONTRASENIA) {
        this.ID = ID;
        this.CONTRASENIA = CONTRASENIA;
    }

    public Administracion(int ID, String NOMBRES, String APELLIDOS, String DNI, String EDAD, int NUMERO_TELEFONO, String GENERO, String CARGO, String CONTRASENIA) {
        this.ID = ID;
        this.NOMBRES = NOMBRES;
        this.APELLIDOS = APELLIDOS;
        this.DNI = DNI;
        this.EDAD = EDAD;
        this.NUMERO_TELEFONO = NUMERO_TELEFONO;
        this.GENERO = GENERO;
        this.CARGO = CARGO;
        this.CONTRASENIA = CONTRASENIA;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNOMBRES() {
        return NOMBRES;
    }

    public void setNOMBRES(String NOMBRES) {
        this.NOMBRES = NOMBRES;
    }

    public String getAPELLIDOS() {
        return APELLIDOS;
    }

    public void setAPELLIDOS(String APELLIDOS) {
        this.APELLIDOS = APELLIDOS;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getEDAD() {
        return EDAD;
    }

    public void setEDAD(String EDAD) {
        this.EDAD = EDAD;
    }

    public int getNUMERO_TELEFONO() {
        return NUMERO_TELEFONO;
    }

    public void setNUMERO_TELEFONO(int NUMERO_TELEFONO) {
        this.NUMERO_TELEFONO = NUMERO_TELEFONO;
    }

    public String getGENERO() {
        return GENERO;
    }

    public void setGENERO(String GENERO) {
        this.GENERO = GENERO;
    }

    public String getCARGO() {
        return CARGO;
    }

    public void setCARGO(String CARGO) {
        this.CARGO = CARGO;
    }

    public String getCONTRASENIA() {
        return CONTRASENIA;
    }

    public void setCONTRASENIA(String CONTRASENIA) {
        this.CONTRASENIA = CONTRASENIA;
    }

    public String[] getData() {
        return new String[]{"" + ID, NOMBRES, APELLIDOS, DNI, EDAD, "" + NUMERO_TELEFONO, GENERO, CARGO, CONTRASENIA};
    }
}
