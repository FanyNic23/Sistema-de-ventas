/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Personas;

/**
 *
 * @author Genji DL
 */
public class Vendedores extends Administracion {

    private float PAGO_MENSUAL;

    public Vendedores() {
    }

    public Vendedores(int ID) {
        super(ID);
    }

    public Vendedores(float PAGO_MENSUAL, int ID, String NOMBRES, String APELLIDOS, String DNI, String EDAD, int NUMERO_TELEFONO, String GENERO, String CARGO, String CONTRASENIA) {
        super(ID, NOMBRES, APELLIDOS, DNI, EDAD, NUMERO_TELEFONO, GENERO, CARGO, CONTRASENIA);
        this.PAGO_MENSUAL = PAGO_MENSUAL;
    }

    public float getPAGO_MENSUAL() {
        return PAGO_MENSUAL;
    }

    public void setPAGO_MENSUAL(float PAGO_MENSUAL) {
        this.PAGO_MENSUAL = PAGO_MENSUAL;
    }

    public String[] getData() {
        String[] administracionData = super.getData();
        String[] vendedoresData = new String[]{"" + getPAGO_MENSUAL()};

        String[] combinedData = new String[administracionData.length + vendedoresData.length];
        System.arraycopy(administracionData, 0, combinedData, 0, administracionData.length);
        System.arraycopy(vendedoresData, 0, combinedData, administracionData.length, vendedoresData.length);

        return combinedData;
    }

}
