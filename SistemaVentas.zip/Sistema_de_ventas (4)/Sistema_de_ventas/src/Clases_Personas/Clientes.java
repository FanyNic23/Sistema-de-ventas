/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Personas;

/**
 *
 * @author Genji DL
 */
public class Clientes extends Administracion {

    public Clientes(int ID, String NOMBRES, String APELLIDOS, String DNI, String EDAD, int NUMERO_TELEFONO, String GENERO, String CARGO, String CONTRASENIA) {
        super(ID, NOMBRES, APELLIDOS, DNI, EDAD, NUMERO_TELEFONO, GENERO, CARGO, CONTRASENIA);
    }

    public Clientes(int ID) {
        super(ID);
    }

    
    public Clientes() {
    }

    public String[] getData() {
        String[] ClienteData = super.getData();
        return ClienteData;
    }

}
